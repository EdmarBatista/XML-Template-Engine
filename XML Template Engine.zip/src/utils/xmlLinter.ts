import { linter, Diagnostic } from '@codemirror/lint';
import { xmlLanguage } from '@codemirror/lang-xml';
import { EditorView } from '@codemirror/view';
import { verificarVariaveisXml } from './xmlEditorCompletions';
import { extrairVariaveisDaExpressao, validarExpressao } from './expressionEvaluator';

const ALLOWED_TAGS = new Set([
  // Estrutura Base
  'documento', 'formulario', 'conteudo',

  // Formulário
  'grupo',
  'input', 'number', 'date', 'textarea', 'select', 'option', 'checkbox', 'radio', 'tabela', 'coluna',

  // Blocos de Conteúdo
  'secao', 'titulo', 'subtitulo', 'p', 'lista', 'lista_numerada', 'item', 'hr',

  // Controle de Fluxo
  'if', 'condicao', 'foreach', 'for-each',

  // Estrutura de Tabela no Conteúdo
  'cabecalho', 'celula', 'linhas', 'linha',

  // Estilos Inline
  'b', 'i', 'u', 's', 'mark', 'cor', 'a', 'br'
]);

/** Diagnóstico genérico (independente do CodeMirror), testável em Node. */
export interface XmlDiagnostico {
  from: number;
  to: number;
  severity: 'error' | 'warning';
  message: string;
}

/** Normaliza um token de uso de variável: remove índices [n] e espaços. */
function normalizarChaveUso(token: string): string {
  return token.replace(/\[\d+\]/g, '').replace(/\s+/g, '');
}

/**
 * Analisa o texto XML e produz todos os diagnósticos de lint:
 *  1. erros sintáticos do parser (lezer): tags malformadas, aspas/atributos quebrados, fechamento divergente;
 *  2. tags fora da whitelist (1 diagnóstico por tag, sem duplicar abertura/fechamento);
 *  3. sintaxe inválida em atributos expr="...";
 *  4. variáveis usadas sem campo declarado no <formulario> e campos declarados nunca usados.
 *
 * Posições são relativas à string `doc` (que corresponde ao conteúdo do editor).
 */
export function coletarDiagnosticosXml(doc: string): XmlDiagnostico[] {
  const diags: XmlDiagnostico[] = [];
  if (!doc) return diags;

  const tree = xmlLanguage.parser.parse(doc);

  const tagsDesconhecidas = new Map<string, number>(); // tag -> posição da 1ª abertura
  const exprAttrs: { valor: string; from: number; to: number }[] = [];
  const usos = new Map<string, number>(); // variável (normalizada) -> 1ª posição de uso

  const registrarUso = (nome: string, pos: number) => {
    const chave = normalizarChaveUso(nome);
    if (chave && !usos.has(chave)) usos.set(chave, pos);
  };

  tree.cursor().iterate(node => {
    const text = doc.slice(node.from, node.to);

    // 1) Erros sintáticos detectados pelo parser do lezer
    if (node.type.isError) {
      let from = node.from;
      let to = node.to;
      if (to <= from) {
        // nós de erro podem ter tamanho zero; garante um intervalo de 1 caractere
        to = Math.min(doc.length, from + 1);
        from = Math.max(0, to - 1);
      }
      diags.push({
        from,
        to,
        severity: 'error',
        message: 'Erro de sintaxe XML: verifique aspas, atributos e o fechamento das tags.',
      });
      return;
    }

    if (node.name === 'MismatchedCloseTag') {
      diags.push({
        from: node.from,
        to: Math.max(node.to, node.from + 1),
        severity: 'error',
        message: 'Tag de fechamento não corresponde à tag de abertura.',
      });
      return;
    }

    // 2) Whitelist de tags — apenas a abertura, para não duplicar o erro no fechamento
    if (node.name === 'TagName') {
      if (doc[node.from - 1] === '/') return; // </tag>: fechamento
      const tag = text.toLowerCase();
      if (!ALLOWED_TAGS.has(tag) && !tagsDesconhecidas.has(tag)) {
        tagsDesconhecidas.set(tag, node.from);
      }
      return;
    }

    // 3) Atributos expr="..." — guarda valor e posição para validação de sintaxe
    if (node.name === 'Attribute') {
      const m = /^expr\s*=\s*(['"])([\s\S]*)\1$/.exec(text);
      if (m) {
        const aspas = m[1];
        const openIdx = text.indexOf(aspas);
        exprAttrs.push({
          valor: m[2],
          from: node.from + openIdx + 1,
          to: node.from + text.length - 1,
        });
      }
      return;
    }
  });

  for (const [tag, from] of tagsDesconhecidas) {
    diags.push({
      from,
      to: Math.min(doc.length, from + tag.length),
      severity: 'error',
      message: `Tag <${tag}> não é permitida ou não é reconhecida pelo sistema.`,
    });
  }

  // Valida sintaxe de cada expr="..." encontrada
  for (const attr of exprAttrs) {
    const erro = validarExpressao(attr.valor);
    if (erro) {
      diags.push({
        from: attr.from,
        to: Math.max(attr.to, attr.from + 1),
        severity: 'error',
        message: `Expressão inválida em expr="...": ${erro}`,
      });
    }
    // registra variáveis citadas na expr para a checagem de declaração
    for (const token of extrairVariaveisDaExpressao(attr.valor)) {
      registrarUso(token, attr.from);
    }
  }

  // Registra usos de {{variavel}} (a parte antes do filtro "|")
  const reInterp = /\{\{\s*([\s\S]*?)\s*\}\}/g;
  let interp: RegExpExecArray | null;
  while ((interp = reInterp.exec(doc)) !== null) {
    const parte = interp[1].split('|')[0];
    const idxLocal = interp[1].indexOf(parte);
    registrarUso(parte, interp.index + (idxLocal >= 0 ? idxLocal : 0));
  }

  // 4) Variáveis usadas sem declaração / campos declarados sem uso
  const res = verificarVariaveisXml(doc);

  for (const nome of res.usadasNaoDeclaradas) {
    const pos = usos.get(normalizarChaveUso(nome)) ?? doc.indexOf(nome);
    const from = pos >= 0 ? pos : 0;
    diags.push({
      from,
      to: Math.min(doc.length, from + Math.max(1, nome.length)),
      severity: 'warning',
      message: `Variável "${nome}" é usada, mas não está declarada no <formulario>.`,
    });
  }

  if (res.declaradasNaoUsadas.length > 0) {
    const lista = res.declaradasNaoUsadas.slice(0, 5).join(', ');
    const resto = res.declaradasNaoUsadas.length > 5 ? '…' : '';
    diags.push({
      from: 0,
      to: Math.min(doc.length, 1),
      severity: 'warning',
      message: `Campo(s) declarado(s) no <formulario> mas nunca usado(s) no documento: ${lista}${resto}`,
    });
  }

  return diags;
}

export const xmlLinter = linter((view: EditorView): Diagnostic[] => {
  const doc = view.state.doc.toString();
  return coletarDiagnosticosXml(doc).map(d => ({
    from: d.from,
    to: d.to,
    severity: d.severity,
    message: d.message,
  }));
});
