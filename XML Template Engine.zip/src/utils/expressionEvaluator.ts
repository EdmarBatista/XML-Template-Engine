/**
 * Avaliador de expressões lógicas e de comparação para tags <if expr="...">
 */

function dividirExpressao(expr: string, operador: string): [string, string] | null {
  let aspas: string | null = null;
  let nivel = 0;
  for (let i = 0; i <= expr.length - operador.length; i++) {
    const c = expr[i];
    if (c === "'" || c === '"') {
      if (aspas === c && expr[i - 1] !== '\\') aspas = null;
      else if (!aspas) aspas = c;
      continue;
    }
    if (aspas) continue;
    if (c === '(') nivel++;
    else if (c === ')') nivel--;

    if (nivel === 0 && expr.slice(i, i + operador.length) === operador) {
      return [expr.slice(0, i).trim(), expr.slice(i + operador.length).trim()];
    }
  }
  return null;
}

function avaliarComparacao(expr: string, dados: Record<string, any>): boolean {
  expr = expr.trim().replace(/^\((.*)\)$/, '$1').trim();
  const match = expr.match(/^([a-zA-Z_]\w*)\s*(==|!=|>=|<=|>|<)\s*(.+)$/);
  if (!match) {
    // Caso de expressão booleana simples como "urgente" ou "!urgente"
    const singleVarMatch = expr.match(/^(!)?([a-zA-Z_]\w*)$/);
    if (singleVarMatch) {
      const isNeg = singleVarMatch[1] === '!';
      const varName = singleVarMatch[2];
      const val = Boolean(dados[varName]);
      return isNeg ? !val : val;
    }
    return false;
  }

  const [, varName, operator, rawValue] = match;
  const leftValue = dados[varName] !== undefined ? dados[varName] : '';
  let rightValue: any = rawValue.trim();

  if ((rightValue.startsWith("'") && rightValue.endsWith("'")) || (rightValue.startsWith('"') && rightValue.endsWith('"'))) {
    rightValue = rightValue.slice(1, -1);
  } else if (rightValue === 'true') {
    rightValue = true;
  } else if (rightValue === 'false') {
    rightValue = false;
  } else if (rightValue !== '' && !isNaN(Number(rightValue))) {
    rightValue = Number(rightValue);
  }

  const numLeft = Number(leftValue);
  const numRight = Number(rightValue);
  const isBothNumeric = !isNaN(numLeft) && !isNaN(numRight) && leftValue !== '' && rightValue !== '';

  switch (operator) {
    case '==':
      if (typeof leftValue === 'boolean' || typeof rightValue === 'boolean') {
        return Boolean(leftValue) === Boolean(rightValue);
      }
      if (isBothNumeric) {
        return numLeft === numRight;
      }
      return String(leftValue).trim() === String(rightValue).trim();
    case '!=':
      if (typeof leftValue === 'boolean' || typeof rightValue === 'boolean') {
        return Boolean(leftValue) !== Boolean(rightValue);
      }
      if (isBothNumeric) {
        return numLeft !== numRight;
      }
      return String(leftValue).trim() !== String(rightValue).trim();
    case '>':
      return isBothNumeric ? numLeft > numRight : String(leftValue) > String(rightValue);
    case '<':
      return isBothNumeric ? numLeft < numRight : String(leftValue) < String(rightValue);
    case '>=':
      return isBothNumeric ? numLeft >= numRight : String(leftValue) >= String(rightValue);
    case '<=':
      return isBothNumeric ? numLeft <= numRight : String(leftValue) <= String(rightValue);
    default:
      return false;
  }
}

export function decodificarEntidadesXml(str: string): string {
  if (!str) return '';
  let res = String(str);
  let prev = '';
  // Decodifica repetidamente enquanto houver entidades aninhadas (ex: &amp;apos; -> &apos; -> ')
  while (res !== prev && res.includes('&')) {
    prev = res;
    res = res
      .replace(/&amp;/g, '&')
      .replace(/&apos;/g, "'")
      .replace(/&quot;/g, '"')
      .replace(/&gt;/g, '>')
      .replace(/&lt;/g, '<');
  }
  return res;
}

export function avaliarExpressao(expr: string, dados: Record<string, any>): boolean {
  if (!expr) return true;

  const limpa = decodificarEntidadesXml(expr).trim();

  // Tratamento de operadores OR (|| ou OR)
  const ou = dividirExpressao(limpa, '||') || dividirExpressao(limpa, ' OR ');
  if (ou) {
    return avaliarExpressao(ou[0], dados) || avaliarExpressao(ou[1], dados);
  }

  // Tratamento de operadores AND (&& ou AND)
  const e = dividirExpressao(limpa, '&&') || dividirExpressao(limpa, ' AND ');
  if (e) {
    return avaliarExpressao(e[0], dados) && avaliarExpressao(e[1], dados);
  }

  return avaliarComparacao(limpa, dados);
}

export function extrairVariaveisDaExpressao(expr: string): string[] {
  if (!expr) return [];
  const decodificado = decodificarEntidadesXml(expr);
  const limpo = decodificado
    .replace(/'[^']*'/g, '')
    .replace(/"[^"]*"/g, '')
    .replace(/[=!<>+&|()[\],]+/g, ' ')
    .replace(/\b(true|false|null|undefined|AND|OR|and|or|not)\b/gi, ' ')
    .replace(/\b\d+(\.\d+)?\b/g, ' ');

  return limpo
    .split(/\s+/)
    .map(token => token.trim())
    .filter(token => /^[a-zA-Z_][a-zA-Z0-9_\.]*$/.test(token));
}

/**
 * Verifica se há aspas simples ou duplas desbalanceadas (não escapadas).
 */
function temAspasDesbalanceadas(s: string): boolean {
  let aspas: string | null = null;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (c === "'" || c === '"') {
      if (aspas === c && s[i - 1] !== '\\') aspas = null;
      else if (!aspas) aspas = c;
    }
  }
  return aspas !== null;
}

/**
 * Verifica se os parênteses estão balanceados, ignorando conteúdo entre aspas.
 */
function temParentesesBalanceados(s: string): boolean {
  let nivel = 0;
  let aspas: string | null = null;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (c === "'" || c === '"') {
      if (aspas === c && s[i - 1] !== '\\') aspas = null;
      else if (!aspas) aspas = c;
      continue;
    }
    if (aspas) continue;
    if (c === '(') nivel++;
    else if (c === ')') {
      nivel--;
      if (nivel < 0) return false;
    }
  }
  return nivel === 0;
}

/**
 * Valida a sintaxe de uma expressão usada em expr="...".
 * Aceita as mesmas formas que `avaliarExpressao` entende:
 *   - "urgente" ou "!urgente"
 *   - "campo == valor", "campo != valor", "campo > 5", etc.
 *   - combinações com && / || (ou AND / OR) e parênteses externos.
 *
 * Retorna null se a expressão for válida ou uma mensagem de erro descritiva.
 * Não verifica se as variáveis citadas existem — isso é feito pelo linter do editor.
 */
export function validarExpressao(expr: string): string | null {
  const limpa = decodificarEntidadesXml(expr).trim();
  if (!limpa) return null; // vazio = condição sempre verdadeira (aceito)

  if (temAspasDesbalanceadas(limpa)) {
    return 'Aspas desbalanceadas na expressão.';
  }
  if (!temParentesesBalanceados(limpa)) {
    return 'Parênteses desbalanceados na expressão.';
  }

  const validarFolha = (folha: string): string | null => {
    // Expressão booleana simples: "urgente" ou "!urgente"
    if (/^!?\s*[A-Za-z_]\w*$/.test(folha)) return null;

    // Comparação: "campo op valor" (aceita acesso a tabela/coluna: it._indice, item.nome, tabela[0].col)
    const m = folha.match(/^([A-Za-z_]\w*(?:\.[A-Za-z_]\w*|\[\s*\d+\s*\])*)\s*(==|!=|>=|<=|>|<)\s*(.+)$/);
    if (!m) {
      return 'Expressão não reconhecida. Use "campo == valor", "!campo" ou combine com && / ||.';
    }

    const rhs = m[3].trim();
    if (!rhs) return `Faltou o valor à direita do operador "${m[2]}".`;

    // Valor entre aspas (pode conter espaços e acentos)
    if ((rhs.startsWith("'") && rhs.endsWith("'")) || (rhs.startsWith('"') && rhs.endsWith('"'))) {
      return null;
    }
    if (/^(true|false)$/i.test(rhs)) return null;
    if (/^-?\d+(\.\d+)?$/.test(rhs)) return null;
    // Comparação entre variáveis (ex.: campo == outroCampo)
    if (/^[A-Za-z_]\w*(?:\.[A-Za-z_]\w*|\[\s*\d+\s*\])*$/.test(rhs)) return null;

    return `O valor "${rhs}" deve estar entre aspas (ex.: '${rhs}') ou ser true/false/número.`;
  };

  const validarComposto = (s: string): string | null => {
    const ou = dividirExpressao(s, '||') || dividirExpressao(s, ' OR ');
    if (ou) return validarComposto(ou[0]) ?? validarComposto(ou[1]);

    const e = dividirExpressao(s, '&&') || dividirExpressao(s, ' AND ');
    if (e) return validarComposto(e[0]) ?? validarComposto(e[1]);

    let folha = s.trim();
    // Remove pares externos de parênteses, ex.: "(a > 5)" -> "a > 5"
    while (
      folha.startsWith('(') &&
      folha.endsWith(')') &&
      temParentesesBalanceados(folha.slice(1, -1))
    ) {
      folha = folha.slice(1, -1).trim();
    }
    if (!folha) return 'Expressão vazia entre parênteses.';
    return validarFolha(folha);
  };

  return validarComposto(limpa);
}
