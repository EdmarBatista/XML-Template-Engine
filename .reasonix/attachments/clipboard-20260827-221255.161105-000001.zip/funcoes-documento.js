/**
 * Funções auxiliares do Motor de Templates XML
 *
 * Importação:
 * <script src="funcoes-documento.js"></script>
 *
 * Regras:
 *
 * <number>
 *     Campo numérico comum.
 *
 * <number tipo="moeda">
 *     Campo monetário.
 *
 * <number tipo="cnpj">
 *     Campo CNPJ.
 *
 * <number tipo="cep">
 *     Campo CEP.
 *
 * O atributo "tipo" define o comportamento específico do campo.
 */


/* ================================================================
   MOEDA
   ================================================================ */

/*
 * Formata moeda para exibição.
 *
 * Quando recebe um NUMBER:
 *
 *     1500
 *
 * retorna:
 *
 *     "1.500,00"
 *
 * Durante a digitação:
 *
 *     "1"      -> "0,01"
 *     "12"     -> "0,12"
 *     "123"    -> "1,23"
 *     "1234"   -> "12,34"
 *     "12345"  -> "123,45"
 *     "123456" -> "1.234,56"
 *
 * A função não manipula DOM.
 */
function formatarMoeda(valor) {

    if (
        valor === null ||
        valor === undefined ||
        valor === ""
    ) {
        return "";
    }

    /*
     * Quando o estado já contém um número:
     *
     * 1500
     *
     * deve ser exibido como:
     *
     * 1.500,00
     */
    if (typeof valor === "number") {

        if (!Number.isFinite(valor)) {
            return "";
        }

        return valor
            .toFixed(2)
            .replace(".", ",")
            .replace(
                /\B(?=(\d{3})+(?!\d))/g,
                "."
            );
    }

    /*
     * Durante a digitação:
     *
     * "123456"
     *
     * significa:
     *
     * 1.234,56
     */
    const numeros =
        String(valor).replace(/\D/g, "");

    if (!numeros) {
        return "";
    }

    const numero =
        parseInt(numeros, 10) / 100;

    return numero
        .toFixed(2)
        .replace(".", ",")
        .replace(
            /\B(?=(\d{3})+(?!\d))/g,
            "."
        );
}


/* ================================================================
   DATA
   ================================================================ */

function converterFormatoData(
    data,
    formatoDestino = "BR"
) {

    if (
        data === null ||
        data === undefined ||
        data === ""
    ) {
        return data;
    }

    data =
        String(data).trim();

    /*
     * ISO -> BR
     *
     * 2026-08-12
     * ->
     * 12/08/2026
     */
    if (
        /^\d{4}-\d{2}-\d{2}$/.test(data)
    ) {

        const [
            ano,
            mes,
            dia
        ] = data.split("-");

        return (
            formatoDestino === "US" ||
            formatoDestino === "ISO"
        )
            ? data
            : `${dia}/${mes}/${ano}`;
    }

    /*
     * BR -> ISO
     *
     * 12/08/2026
     * ->
     * 2026-08-12
     */
    if (
        /^\d{2}\/\d{2}\/\d{4}$/.test(data)
    ) {

        const [
            dia,
            mes,
            ano
        ] = data.split("/");

        return formatoDestino === "BR"
            ? data
            : `${ano}-${mes}-${dia}`;
    }

    return data;
}


/* ================================================================
   DATA POR EXTENSO
   ================================================================ */

function dataPorExtenso(data) {

    if (!(data instanceof Date)) {

        if (typeof data === "string") {

            /*
             * ISO
             */
            if (
                /^\d{4}-\d{2}-\d{2}$/.test(data)
            ) {

                const [
                    ano,
                    mes,
                    dia
                ] =
                    data
                        .split("-")
                        .map(Number);

                data =
                    new Date(
                        ano,
                        mes - 1,
                        dia
                    );

            }

            /*
             * BR
             */
            else if (
                /^\d{2}\/\d{2}\/\d{4}$/.test(data)
            ) {

                const [
                    dia,
                    mes,
                    ano
                ] =
                    data
                        .split("/")
                        .map(Number);

                data =
                    new Date(
                        ano,
                        mes - 1,
                        dia
                    );

            }

            /*
             * Outros formatos aceitos pelo Date
             */
            else {

                data =
                    new Date(data);
            }
        }
    }

    if (
        !(data instanceof Date) ||
        isNaN(data.getTime())
    ) {
        return "";
    }

    const meses = [
        "janeiro",
        "fevereiro",
        "março",
        "abril",
        "maio",
        "junho",
        "julho",
        "agosto",
        "setembro",
        "outubro",
        "novembro",
        "dezembro"
    ];

    return `${data.getDate()} de ${meses[data.getMonth()]} de ${data.getFullYear()}`;
}


/* ================================================================
   NÚMERO POR EXTENSO
   ================================================================ */

function numeroPorExtenso(
    numero,
    num_dois = true
) {

    if (
        numero === null ||
        numero === undefined ||
        numero === ""
    ) {
        return "";
    }

    numero =
        Number(numero);

    if (
        !Number.isFinite(numero)
    ) {
        return "";
    }

    numero =
        Math.trunc(numero);

    const dois =
        num_dois
            ? "dois"
            : "duas";

    const unidades = [
        "",
        "um",
        dois,
        "três",
        "quatro",
        "cinco",
        "seis",
        "sete",
        "oito",
        "nove"
    ];

    const especiais = [
        "dez",
        "onze",
        "doze",
        "treze",
        "catorze",
        "quinze",
        "dezesseis",
        "dezessete",
        "dezoito",
        "dezenove"
    ];

    const dezenas = [
        "",
        "",
        "vinte",
        "trinta",
        "quarenta",
        "cinquenta",
        "sessenta",
        "setenta",
        "oitenta",
        "noventa"
    ];

    const centenas = [
        "",
        "cento",
        "duzentos",
        "trezentos",
        "quatrocentos",
        "quinhentos",
        "seiscentos",
        "setecentos",
        "oitocentos",
        "novecentos"
    ];

    if (numero === 0) {
        return "zero";
    }

    if (numero < 0) {

        return (
            "menos " +
            numeroPorExtenso(
                Math.abs(numero),
                num_dois
            )
        );
    }

    let extenso = "";


    /* ============================================================
       BILHÕES
       ============================================================ */

    if (numero >= 1000000000) {

        const bilhoes =
            Math.floor(
                numero / 1000000000
            );

        extenso +=
            bilhoes === 1
                ? "um bilhão"
                : numeroPorExtenso(
                    bilhoes,
                    num_dois
                ) + " bilhões";

        numero %=
            1000000000;

        if (numero > 0) {
            extenso += " ";
        }
    }


    /* ============================================================
       MILHÕES
       ============================================================ */

    if (numero >= 1000000) {

        const milhoes =
            Math.floor(
                numero / 1000000
            );

        extenso +=
            milhoes === 1
                ? "um milhão"
                : numeroPorExtenso(
                    milhoes,
                    num_dois
                ) + " milhões";

        numero %=
            1000000;

        if (numero > 0) {
            extenso += " ";
        }
    }


    /* ============================================================
       MILHARES
       ============================================================ */

    if (numero >= 1000) {

        const milhares =
            Math.floor(
                numero / 1000
            );

        extenso +=
            milhares === 1
                ? "mil"
                : numeroPorExtenso(
                    milhares,
                    num_dois
                ) + " mil";

        numero %=
            1000;

        if (numero > 0) {
            extenso += " ";
        }
    }


    /* ============================================================
       CENTENAS
       ============================================================ */

    if (numero >= 100) {

        const centena =
            Math.floor(
                numero / 100
            );

        extenso +=
            numero === 100
                ? "cem"
                : centenas[centena];

        numero %=
            100;

        if (numero > 0) {
            extenso += " e ";
        }
    }


    /* ============================================================
       DEZENAS
       ============================================================ */

    if (numero >= 10) {

        if (numero < 20) {

            extenso +=
                especiais[numero - 10];

        } else {

            const dezena =
                Math.floor(
                    numero / 10
                );

            extenso +=
                dezenas[dezena];

            const unidade =
                numero % 10;

            if (unidade > 0) {

                extenso +=
                    " e " +
                    unidades[unidade];
            }
        }

    }

    /* ============================================================
       UNIDADES
       ============================================================ */

    else if (numero > 0) {

        extenso +=
            unidades[numero];
    }

    return extenso;
}


/* ================================================================
   NÚMERO ROMANO
   ================================================================ */

function converterParaRomano(numero) {

    numero =
        Number(numero);

    if (
        !Number.isFinite(numero) ||
        numero <= 0
    ) {
        return "";
    }

    numero =
        Math.floor(numero);

    const romanos = [
        {
            value: 1000,
            symbol: "M"
        },
        {
            value: 900,
            symbol: "CM"
        },
        {
            value: 500,
            symbol: "D"
        },
        {
            value: 400,
            symbol: "CD"
        },
        {
            value: 100,
            symbol: "C"
        },
        {
            value: 90,
            symbol: "XC"
        },
        {
            value: 50,
            symbol: "L"
        },
        {
            value: 40,
            symbol: "XL"
        },
        {
            value: 10,
            symbol: "X"
        },
        {
            value: 9,
            symbol: "IX"
        },
        {
            value: 5,
            symbol: "V"
        },
        {
            value: 4,
            symbol: "IV"
        },
        {
            value: 1,
            symbol: "I"
        }
    ];

    let resultado = "";

    for (const romano of romanos) {

        while (
            numero >= romano.value
        ) {

            resultado +=
                romano.symbol;

            numero -=
                romano.value;
        }
    }

    return resultado;
}


/* ================================================================
   E-MAIL
   ================================================================ */

function validarEmail(email) {

    if (
        email === null ||
        email === undefined
    ) {
        return false;
    }

    const valor =
        String(email).trim();

    return (
        !!valor &&
        /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/
            .test(valor)
    );
}


/* ================================================================
   CNPJ
   ================================================================ */

/*
 * Formatação progressiva:
 *
 * 1
 * 12
 * 12.3
 * 12.345
 * 12.345.678
 * 12.345.678/9
 * 12.345.678/9012
 * 12.345.678/9012-34
 */
function formatarCNPJ(valor) {

    if (
        valor === null ||
        valor === undefined
    ) {
        return "";
    }

    let cnpj =
        String(valor)
            .replace(/\D/g, "")
            .substring(0, 14);


    /*
     * 12.345.678/9012-34
     */
    if (cnpj.length > 12) {

        return cnpj.replace(
            /^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/,
            "$1.$2.$3/$4-$5"
        );
    }


    /*
     * 12.345.678/9012
     */
    if (cnpj.length > 8) {

        return cnpj.replace(
            /^(\d{2})(\d{3})(\d{3})(\d{0,4})/,
            "$1.$2.$3/$4"
        );
    }


    /*
     * 12.345.678
     */
    if (cnpj.length > 5) {

        return cnpj.replace(
            /^(\d{2})(\d{3})(\d{0,3})/,
            "$1.$2.$3"
        );
    }


    /*
     * 12.345
     */
    if (cnpj.length > 2) {

        return cnpj.replace(
            /^(\d{2})(\d{0,3})/,
            "$1.$2"
        );
    }


    return cnpj;
}


/* ================================================================
   CEP
   ================================================================ */

/*
 * Formatação progressiva:
 *
 * 30123456
 * ->
 * 30123-456
 */
function formatarCEP(valor) {

    if (
        valor === null ||
        valor === undefined
    ) {
        return "";
    }

    let cep =
        String(valor)
            .replace(/\D/g, "")
            .substring(0, 8);

    if (cep.length > 5) {

        cep = cep.replace(
            /^(\d{5})(\d{1,3})/,
            "$1-$2"
        );
    }

    return cep;
}


/* ================================================================
   FORMATAÇÃO PELO TIPO
   ================================================================ */

/*
 * A formatação é determinada exclusivamente pelo atributo
 * "tipo" do XML.
 *
 * Exemplos:
 *
 * tipo="moeda"
 * tipo="cnpj"
 * tipo="cep"
 */
function aplicarMascaraCampo(
    valor,
    tipo
) {

    if (!tipo) {
        return valor ?? "";
    }

    const nome =
        String(tipo)
            .toLowerCase()
            .trim();

    switch (nome) {

        case "moeda":
            return formatarMoeda(valor);

        case "cnpj":
            return formatarCNPJ(valor);

        case "cep":
            return formatarCEP(valor);

        default:
            return valor ?? "";
    }
}


/* ================================================================
   NORMALIZAÇÃO DE VALORES
   ================================================================ */

/*
 * Converte o valor recebido para o formato que deve ser
 * armazenado no estado.
 *
 * CNPJ:
 *
 *     "12.345.678/0001-99"
 *     ->
 *     "12345678000199"
 *
 * CEP:
 *
 *     "30.123-456"
 *     ->
 *     "30123456"
 *
 * MOEDA:
 *
 *     "1.500,00"
 *     ->
 *     1500
 */
function normalizarValorCampo(
    valor,
    tipo
) {

    const nome =
        String(tipo || "")
            .toLowerCase()
            .trim();

    if (
        valor === null ||
        valor === undefined ||
        valor === ""
    ) {
        return "";
    }


    /* ============================================================
       CNPJ
       ============================================================ */

    if (nome === "cnpj") {

        return String(valor)
            .replace(/\D/g, "")
            .substring(0, 14);
    }


    /* ============================================================
       CEP
       ============================================================ */

    if (nome === "cep") {

        return String(valor)
            .replace(/\D/g, "")
            .substring(0, 8);
    }


    /* ============================================================
       MOEDA
       ============================================================ */

    if (nome === "moeda") {

        /*
         * Já é número.
         */
        if (typeof valor === "number") {

            return Number.isFinite(valor)
                ? valor
                : "";
        }

        const texto =
            String(valor).trim();

        if (!texto) {
            return "";
        }


        /*
         * Valor brasileiro:
         *
         * 1.234,56
         *
         * ->
         *
         * 1234.56
         */
        if (texto.includes(",")) {

            const numero =
                parseFloat(
                    texto
                        .replace(/\./g, "")
                        .replace(",", ".")
                );

            return Number.isFinite(numero)
                ? numero
                : "";
        }


        /*
         * Número simples:
         *
         * 1500
         *
         * ->
         *
         * 1500
         */
        const numero =
            Number(texto);

        return Number.isFinite(numero)
            ? numero
            : "";
    }


    /*
     * Outros tipos permanecem inalterados.
     */
    return valor;
}


/* ================================================================
   METADADOS DOS CAMPOS
   ================================================================ */

function criarMetadadosCampo(
    campoEl
) {

    if (!campoEl) {
        return null;
    }

    const tag =
        campoEl.tagName
            ? campoEl.tagName.toLowerCase()
            : "";

    const id =
        campoEl.getAttribute("id") || "";

    const label =
        campoEl.getAttribute("label") || id;

    const metadados = {

        id,

        label,

        tipo: tag,

        obrigatorio:
            campoEl.getAttribute(
                "obrigatorio"
            ) === "true",

        descricao:
            campoEl.getAttribute(
                "descricao"
            ) || "",

        placeholder:
            campoEl.getAttribute(
                "placeholder"
            ) || ""
    };


    /*
     * min / max / step
     */
    [
        "min",
        "max",
        "step"
    ].forEach(prop => {

        const valor =
            campoEl.getAttribute(
                prop
            );

        if (valor !== null) {

            metadados[prop] =
                valor;
        }
    });


    /*
     * select / radio
     */
    if (
        tag === "select" ||
        tag === "radio"
    ) {

        metadados.opcoes =
            Array.from(
                campoEl.children
            )
            .filter(
                el =>
                    el.tagName
                        .toLowerCase() ===
                    "option"
            )
            .map(
                el =>
                    el.textContent.trim()
            );
    }

    return metadados;
}


/* ================================================================
   EXTRAÇÃO DOS METADADOS
   ================================================================ */

function extrairMetadadosCampos(
    formularioNode
) {

    const mapa = {};

    if (!formularioNode) {
        return mapa;
    }

    Array.from(
        formularioNode.children
    )
    .filter(
        el =>
            el.tagName
                .toLowerCase() ===
            "grupo"
    )
    .forEach(
        grupoEl => {

            Array.from(
                grupoEl.children
            )
            .forEach(
                campoEl => {

                    const tipos = [
                        "input",
                        "textarea",
                        "number",
                        "date",
                        "checkbox",
                        "radio",
                        "select"
                    ];

                    const tag =
                        campoEl.tagName
                            .toLowerCase();

                    if (
                        !tipos.includes(tag)
                    ) {
                        return;
                    }

                    const metadados =
                        criarMetadadosCampo(
                            campoEl
                        );

                    if (
                        metadados &&
                        metadados.id
                    ) {

                        mapa[
                            metadados.id
                        ] =
                            metadados;
                    }
                }
            );
        }
    );

    return mapa;
}


/* ================================================================
   CAMINHO DO CAMPO
   ================================================================ */

function obterCaminhoCampo(
    campo,
    grupo
) {

    if (!campo) {
        return "";
    }

    const label =
        campo.label ||
        campo.id ||
        "";

    if (!grupo) {
        return label;
    }

    const titulo =
        typeof grupo === "string"
            ? grupo
            : grupo.titulo || "";

    return titulo
        ? `${titulo} - ${label}`
        : label;
}


/* ================================================================
   OBTÉM METADADOS DE UM CAMPO
   ================================================================ */

function obterMetadadosCampo(
    campos,
    id
) {

    if (
        !campos ||
        !id
    ) {
        return null;
    }

    return campos[id] || null;
}


/* ================================================================
   FILTROS DO DOCUMENTO
   ================================================================ */

function aplicarFiltroDocumento(
    valor,
    filtro
) {

    if (
        valor === null ||
        valor === undefined ||
        valor === ""
    ) {
        return "";
    }

    switch (filtro) {

        /* ========================================================
           MOEDA
           ======================================================== */

        case "moeda": {

            const bruto =
                normalizarValorCampo(
                    valor,
                    "moeda"
                );

            const formatado =
                formatarMoeda(bruto);

            return formatado === ""
                ? ""
                : `R$ ${formatado}`;
        }


        /* ========================================================
           DATA
           ======================================================== */

        case "data":

            return converterFormatoData(
                valor,
                "BR"
            );


        /* ========================================================
           DATA POR EXTENSO
           ======================================================== */

        case "dataExtenso":

        case "data_extenso":

            return dataPorExtenso(
                valor
            );


        /* ========================================================
           NÚMERO POR EXTENSO
           ======================================================== */

        case "extenso":

        case "numeroExtenso":

        case "numero_extenso":

        case "numeroPorExtenso":

            return numeroPorExtenso(
                valor
            );


        /* ========================================================
           ROMANO
           ======================================================== */

        case "romano":

            return converterParaRomano(
                valor
            );


        /* ========================================================
           CNPJ
           ======================================================== */

        case "cnpj":

            return formatarCNPJ(
                normalizarValorCampo(
                    valor,
                    "cnpj"
                )
            );


        /* ========================================================
           CEP
           ======================================================== */

        case "cep":

            return formatarCEP(
                normalizarValorCampo(
                    valor,
                    "cep"
                )
            );


        /* ========================================================
           SEM FILTRO
           ======================================================== */

        default:

            return valor;
    }
}


/* ================================================================
   API PÚBLICA
   ================================================================ */

window.DocumentoUtils = {

    /*
     * Formatação
     */
    formatarMoeda,
    formatarCNPJ,
    formatarCEP,
    aplicarMascaraCampo,

    /*
     * Normalização
     */
    normalizarValorCampo,

    /*
     * Datas
     */
    converterFormatoData,
    dataPorExtenso,

    /*
     * Números
     */
    numeroPorExtenso,
    converterParaRomano,

    /*
     * Validação
     */
    validarEmail,

    /*
     * Metadados
     */
    criarMetadadosCampo,
    extrairMetadadosCampos,
    obterCaminhoCampo,
    obterMetadadosCampo,

    /*
     * Filtros
     */
    aplicarFiltroDocumento
};