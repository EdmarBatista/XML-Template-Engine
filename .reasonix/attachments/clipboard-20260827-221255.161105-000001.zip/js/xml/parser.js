(function(global){
'use strict';

/* =========================================================
   Parser: XML -> campos / estado / variáveis
   ========================================================= */

function parseXMLString(xmlString){
    const parser=new DOMParser();
    const xmlDoc=parser.parseFromString(xmlString,'text/xml');
    if(xmlDoc.querySelector('parsererror'))throw new Error('Erro ao interpretar XML');
    return xmlDoc;
}

function extrairCampos(formularioNode){
    const grupos=[];
    const campos={};
    formularioNode.querySelectorAll(':scope > grupo').forEach(grupoEl=>{
        const titulo=grupoEl.getAttribute('titulo')||'Grupo';
        const ids=[];
        Array.from(grupoEl.children).forEach(campoEl=>{
            const tag=campoEl.tagName.toLowerCase();
            const tipos=['input','select','textarea','number','date','checkbox','radio'];
            if(!tipos.includes(tag))return;
            const id=campoEl.getAttribute('id');
            if(!id)return;
            const base=window.DocumentoUtils?.criarMetadadosCampo(campoEl)||{id,label:campoEl.getAttribute('label')||id,tipo:tag,descricao:campoEl.getAttribute('descricao')||''};
            const campo={...base};
            campo.tipoInput=campoEl.getAttribute('tipo')||'text';
            campo.validar=campoEl.getAttribute('validar')||campoEl.getAttribute('validacao')||'';
            campo.placeholder=campoEl.getAttribute('placeholder')||campo.placeholder||'';
            if(['input','number','date','textarea'].includes(tag)){
                campo.tipo=tag==='number'?'number':tag==='date'?'date':tag==='textarea'?'textarea':'input';
                if(tag==='number'){
                    const min=campoEl.getAttribute('min'),step=campoEl.getAttribute('step'),max=campoEl.getAttribute('max');
                    if(min!==null)campo.min=min;if(max!==null)campo.max=max;if(step!==null)campo.step=step;
                }
                if(tag==='textarea')campo.rows=campoEl.getAttribute('rows')||4;
            }else if(tag==='select'||tag==='radio'){
                campo.tipo=tag;
                campo.opcoes=Array.from(campoEl.children).filter(el=>el.tagName.toLowerCase()==='option').map(opt=>opt.textContent.trim());
            }
            campos[id]=campo;
            ids.push(id);
        });
        grupos.push({titulo,campos:ids});
    });
    return {grupos,campos};
}

function construirEstadoInicial(campos){
    const estado={};
    Object.values(campos).forEach(campo=>{estado[campo.id]=campo.tipo==='checkbox'?false:'';});
    return estado;
}

function extrairVariaveis(texto){
    const matches=texto.match(/\{\{(\w+)(?:\s*\|\s*(\w+))?\}\}/g);
    if(!matches)return '';

    return matches.map(match=>{
        const m=match.match(/\{\{(\w+)(?:\s*\|\s*(\w+))?\}\}/);
        return m?m[1]:'';
    }).filter(Boolean).join(',');
}

function obterTextoModelo(node){
    if(!node)return '';

    if(node.tipo==='texto'){
        return node.texto||'';
    }

    return (node.filhos||[])
        .map(obterTextoModelo)
        .join('');
}

global.EDM_XmlParser = {
    parseXMLString,
    extrairCampos,
    construirEstadoInicial,
    extrairVariaveis,
    obterTextoModelo
};
})(window);
