(function(global){
'use strict';

/* =========================================================
   Modelo intermediário do documento (XML -> object tree)
   ========================================================= */

function converterNoParaModelo(node){
    if(node.nodeType===Node.TEXT_NODE){
        return {tipo:'texto',texto:node.textContent};
    }

    if(node.nodeType!==Node.ELEMENT_NODE){
        return null;
    }

    const atributos={};
    Array.from(node.attributes).forEach(attr=>{
        atributos[attr.name]=attr.value;
    });

    const filhos=Array.from(node.childNodes)
        .map(converterNoParaModelo)
        .filter(Boolean);

    return {
        tipo:node.tagName.toLowerCase(),
        atributos,
        filhos
    };
}

function converterConteudoParaModelo(conteudoNode){
    return {
        tipo:'conteudo',
        atributos:{},
        filhos:Array.from(conteudoNode.childNodes)
            .map(converterNoParaModelo)
            .filter(Boolean)
    };
}

function criarModeloIntermediarioCompleto(xmlDoc){
    const formularioNode=xmlDoc.querySelector('formulario');
    const conteudoNode=xmlDoc.querySelector('conteudo');
    if(!formularioNode||!conteudoNode)throw new Error('XML inválido: formulário ou conteúdo não encontrado.');
    const formulario=window.EDM_XmlParser.extrairCampos(formularioNode);
    return {
        tipo:'documento',
        formulario,
        dados:window.EDM_XmlParser.construirEstadoInicial(formulario.campos),
        conteudo:converterConteudoParaModelo(conteudoNode)
    };
}

function obterCaminhoCampo(grupos,campos,id){
    const campo=campos?.[id];
    if(!campo)return id;
    const grupo=grupos?.find(g=>g.campos?.includes(id));
    return grupo?`${grupo.titulo} - ${campo.label||id}`:(campo.label||id);
}

function obterTooltipCampo(grupos,campos,id){
    const campo=campos?.[id];
    if(!campo)return id;
    const caminho=obterCaminhoCampo(grupos,campos,id);
    return campo.descricao?`${caminho} — ${campo.descricao}`:caminho;
}

global.EDM_Modelo = {
    converterNoParaModelo,
    converterConteudoParaModelo,
    criarModeloIntermediarioCompleto,
    obterCaminhoCampo,
    obterTooltipCampo
};
})(window);
