/* =========================================================
   MELHORIAS INTERATIVAS — PERSISTÊNCIA / REDIMENSIONAMENTO /
   ARRASTAR XML / VISUALIZAÇÃO DO MODELO
========================================================= */
(function(){
    let panel=null;
    let modo='vars-edit';

    const { aplicarMascaraCampo } = window.EDM_Validacao;
    const { baixarPreenchimentoJSON } = window.EDM_Utils;

    function esc(v){
        return String(v??'')
            .replace(/&/g,'&amp;')
            .replace(/</g,'&lt;')
            .replace(/>/g,'&gt;')
            .replace(/"/g,'&quot;')
            .replace(/'/g,'&#39;');
    }

    function getModel(){
        return window.modelo||{formulario:{grupos:[],campos:{}},dados:{}};
    }

    function salvarValor(id,valor){
        if(typeof window.edmAtualizarCampo==='function') window.edmAtualizarCampo(id,valor);
    }

    function obterCampo(id){
        return getModel().formulario?.campos?.[id]||{};
    }

    function editor(id,valor,listaForeach=false){
        const campo=obterCampo(id);
        const tipo=campo.tipo||'input';
        const value=valor===null||valor===undefined?'':valor;

        // Variáveis usadas como origem de foreach são sempre editadas
        // como lista completa, portanto usam textarea também neste painel.
        if(listaForeach)
            return `<textarea class="edm-var-editor edm-var-list-editor" data-edit-id="${esc(id)}" rows="${Math.max(3,String(value).split(/\\r?\\n/).length)}">${esc(value)}</textarea>`;

        if(tipo==='radio'){
            const opcoes=Array.isArray(campo.opcoes)?campo.opcoes:[];
            const nomeGrupo=`edm-var-radio-${id}`;

            return `<div class="edm-var-radio-group" data-edit-id="${esc(id)}">
                ${opcoes.length
                    ? opcoes.map(op=>`
                        <label class="edm-var-radio-option">
                            <input
                                class="edm-var-editor edm-var-radio"
                                data-edit-id="${esc(id)}"
                                type="radio"
                                name="${esc(nomeGrupo)}"
                                value="${esc(op)}"
                                ${String(op)===String(value)?'checked':''}>
                            <span>${esc(op)}</span>
                        </label>
                    `).join('')
                    : '<span class="edm-var-empty">Nenhuma opção definida.</span>'
                }
            </div>`;
        }

        if(tipo==='checkbox')
            return `<input class="edm-var-editor" data-edit-id="${esc(id)}" type="checkbox" ${value===true?'checked':''}>`;

        if(tipo==='select'){
            const opcoes=campo.opcoes||[];
            return `<select class="edm-var-editor" data-edit-id="${esc(id)}">${opcoes.map(op=>`<option value="${esc(op)}" ${String(op)===String(value)?'selected':''}>${esc(op)}</option>`).join('')}</select>`;
        }

        if(tipo==='textarea')
            return `<textarea class="edm-var-editor" data-edit-id="${esc(id)}" rows="3">${esc(value)}</textarea>`;

        const mascara=String(campo.tipoInput||'').toLowerCase();
        const ehMascara=['moeda','cnpj','cep'].includes(mascara);
        const tipoEditor=ehMascara?'text':tipo==='number'?'number':tipo==='date'?'date':'text';
        const inputMode=ehMascara?'numeric':'';
        const valorExibido=ehMascara?aplicarMascaraCampo(value,mascara):value;
        return `<input class="edm-var-editor" data-edit-id="${esc(id)}" type="${tipoEditor}" inputmode="${inputMode}" value="${esc(valorExibido)}">`;
    }

    function obterListasForeach(modelo){
        const listas=new Set();
        const percorrer=nodes=>{
            (nodes||[]).forEach(node=>{
                if(node?.tipo==='foreach' && node.atributos?.lista){
                    listas.add(String(node.atributos.lista));
                }
                percorrer(node?.filhos);
            });
        };
        percorrer(modelo?.conteudo?.filhos||[]);
        return listas;
    }

    function renderVars(editavel){
        const modelo=getModel();
        const dados=modelo.dados||{};
        const campos=modelo.formulario?.campos||{};
        const listasForeach=obterListasForeach(modelo);
        const ids=Object.keys(campos);

        return `<div class="edm-var-list ${editavel?'':'edm-model-readonly'}">
            ${ids.length?ids.map(id=>{
                const c=campos[id]||{};
                const valor=dados[id];
                const txt=String(valor??'');

                return `<div class="edm-var-item" data-var-row="${esc(id)}">
                    <div class="edm-var-name">
                        <button class="edm-var-row-button" data-focus-id="${esc(id)}">{{${esc(id)}}}</button>
                    </div>
                    <div class="edm-var-value">
                        ${editavel?editor(id,valor,listasForeach.has(id)):`<span class="${txt?'':'edm-var-empty'} ${listasForeach.has(id)?'edm-var-multiline':''}">${txt?esc(txt):'(vazio)'}</span>`}
                        ${c.label?`<div class="edm-var-label ${txt?'preenchido':'vazio'}">${esc(c.label)}</div>`:''}
                    </div>
                </div>`;
            }).join(''):'<div class="edm-var-empty">Nenhuma variável encontrada.</div>'}
        </div>`;
    }

    function renderJsonModelo(){
        const modelo=getModel();
        return `<pre>${esc(JSON.stringify(modelo,null,2))}</pre>`;
    }

    function renderJsonDados(){
        const modelo=getModel();

        // Exatamente a estrutura produzida por baixarPreenchimentoJSON().
        const preenchimento={
            xml:window.edmXmlName||modelo.xml||'',
            dados:modelo.dados||{}
        };

        return `<pre>${esc(JSON.stringify(preenchimento,null,2))}</pre>`;
    }

    function render(){
        if(!panel)return;

        const content=panel.querySelector('#edm-model-content');
        if(!content)return;

        if(modo==='json-modelo'){
            content.innerHTML=renderJsonModelo();
            return;
        }

        if(modo==='json-dados'){
            content.innerHTML=renderJsonDados();
            return;
        }

        // O modo "Variáveis" deste painel é sempre editável.
        // O botão "Edição inline" controla somente a edição no documento.
        content.innerHTML=renderVars(modo==='vars-edit');
    }

    function setModo(novo){
        modo=novo;
        if(!panel)return;

        panel.querySelectorAll('.edm-model-tab').forEach(b=>{
            const ativo=b.dataset.mode===modo;
            b.classList.toggle('active',ativo);
            b.setAttribute('aria-selected',String(ativo));
        });

        render();
    }

    function focusLeft(id){
        if(window.edmIrParaCampo===false)return;
        window.dispatchEvent(new CustomEvent('edm:foco-campo',{detail:{id}}));
    }

    function open(){
        if(!panel){
            panel=document.createElement('section');
            panel.className='edm-model-panel';
            panel.innerHTML=`
                <div class="edm-model-header">
                    <div class="edm-model-title">
                        <i class="fa-solid fa-table-columns" aria-hidden="true"></i>
                        <span>Variáveis / Modelo intermediário</span>
                    </div>
                    <button type="button" id="edm-close-model" title="Fechar" aria-label="Fechar">×</button>
                </div>

                <div class="edm-model-tabs" role="tablist">
                    <button type="button" class="edm-model-tab active" data-mode="vars-edit" aria-selected="true">Variáveis</button>
                    <button type="button" class="edm-model-tab" data-mode="vars-readonly" aria-selected="false">Visualização</button>
                    <button type="button" class="edm-model-tab" data-mode="json-modelo" aria-selected="false">Modelo JSON</button>
                    <button type="button" class="edm-model-tab" data-mode="json-dados" aria-selected="false">Dados JSON</button>
                </div>

                <div class="edm-model-content" id="edm-model-content"></div>`;

            document.body.appendChild(panel);

            panel.querySelector('#edm-close-model').onclick=()=>{
                panel.style.display='none';
            };

            panel.querySelectorAll('.edm-model-tab').forEach(b=>{
                b.onclick=()=>setModo(b.dataset.mode);
            });

            panel.addEventListener('click',e=>{
                const focus=e.target.closest('[data-focus-id]');
                if(focus){
                    e.preventDefault();
                    focusLeft(focus.dataset.focusId);
                }
            });

            panel.addEventListener('input',e=>{
                const editorEl=e.target.closest('[data-edit-id]');
                if(!editorEl || modo!=='vars-edit')return;

                const id=editorEl.dataset.editId;
                const campo=obterCampo(id);

                const mascara=String(campo.tipoInput||'').toLowerCase();
                const ehMascara=['moeda','cnpj','cep'].includes(mascara);

                if(ehMascara){
                    const valorFormatado=aplicarMascaraCampo(editorEl.value,mascara);
                    const valorBruto=window.DocumentoUtils?.normalizarValorCampo
                        ? DocumentoUtils.normalizarValorCampo(valorFormatado,mascara)
                        : valorFormatado;
                    editorEl.value=valorFormatado;
                    salvarValor(id,valorBruto);
                }else{
                    const value=editorEl.type==='checkbox'?editorEl.checked:editorEl.value;
                    salvarValor(id,value);
                }
            });

            panel.addEventListener('change',e=>{
                const editorEl=e.target.closest('[data-edit-id]');
                if(!editorEl || modo!=='vars-edit')return;

                const id=editorEl.dataset.editId;
                const campo=obterCampo(id);
                const mascara=String(campo.tipoInput||'').toLowerCase();
                const ehMascara=['moeda','cnpj','cep'].includes(mascara);
                let value=editorEl.type==='checkbox'
                    ?editorEl.checked
                    :editorEl.value;

                if(ehMascara){
                    const valorFormatado=aplicarMascaraCampo(value,mascara);
                    editorEl.value=valorFormatado;
                    value=window.DocumentoUtils?.normalizarValorCampo
                        ? DocumentoUtils.normalizarValorCampo(valorFormatado,mascara)
                        : valorFormatado;
                }

                salvarValor(id,value);
            });

            panel.addEventListener('dblclick',e=>{
                if(modo!=='vars-edit'){
                    e.preventDefault();
                    e.stopPropagation();
                }
            });
        }

        panel.style.display='flex';
        modo='vars-edit';

        panel.querySelectorAll('.edm-model-tab').forEach(b=>{
            const ativo=b.dataset.mode===modo;
            b.classList.toggle('active',ativo);
            b.setAttribute('aria-selected',String(ativo));
        });

        render();
    }

    window.addEventListener('edm:show-model',open);

    window.addEventListener('edm:modelo-atualizado',()=>{
        if(panel&&panel.style.display!=='none'){
            const editando=panel.querySelector('[data-edit-id]:focus');
            if(!editando)render();
        }
    });

    window.addEventListener('edm:configuracao',()=>{
        if(panel&&panel.style.display!=='none')render();
    });
})();;;;

;
