/* =========================================================
   ARRASTAR XML / JSON — comportamento restaurado
   Mantido no mesmo formato da versão anterior.
========================================================= */
(function(){
    let hint=null;

    const hide=()=>{
        hint?.remove();
        hint=null;
        document.querySelector('.sidebar')?.classList.remove('edm-drop-active');
    };

    const show=()=>{
        if(hint)return;
        hint=document.createElement('div');
        hint.className='edm-drop-hint';
        hint.textContent='Solte um XML ou JSON para carregá-lo';
        document.body.appendChild(hint);
        document.querySelector('.sidebar')?.classList.add('edm-drop-active');
    };

    window.addEventListener('dragenter',e=>{
        if(Array.from(e.dataTransfer?.types||[]).includes('Files')){
            e.preventDefault();
            show();
        }
    });

    window.addEventListener('dragover',e=>{
        if(Array.from(e.dataTransfer?.types||[]).includes('Files')){
            e.preventDefault();
        }
    },{passive:false});

    window.addEventListener('dragleave',e=>{
        if(e.clientX<=0||e.clientY<=0||e.clientX>=innerWidth||e.clientY>=innerHeight){
            hide();
        }
    });

    window.addEventListener('drop',e=>{
        if(!e.dataTransfer?.files?.length)return;
        e.preventDefault();
        hide();

        const file=e.dataTransfer.files[0];
        const ehXml=/\.xml$/i.test(file.name)||file.type==='text/xml'||file.type==='application/xml';
        const ehJson=/\.json$/i.test(file.name)||file.type==='application/json';

        if(!ehXml&&!ehJson){
            alert('Solte um arquivo XML ou JSON de preenchimento.');
            return;
        }

        if(ehJson){
            const carregarJson=window.edmCarregarJSON;
            if(carregarJson){
                carregarJson(file);
                return;
            }

            const inputJson=document.getElementById('upload-json');
            if(inputJson){
                try{
                    const dt=new DataTransfer();
                    dt.items.add(file);
                    inputJson.files=dt.files;
                    inputJson.dispatchEvent(new Event('change',{bubbles:true}));
                }catch(error){}
            }
            return;
        }

        const carregar=window.edmCarregarArquivo;
        if(carregar){
            carregar(file);
            return;
        }

        const input=document.getElementById('upload-xml');
        if(input){
            try{
                const dt=new DataTransfer();
                dt.items.add(file);
                input.files=dt.files;
                input.dispatchEvent(new Event('change',{bubbles:true}));
            }catch(error){}
        }
    });
})();
