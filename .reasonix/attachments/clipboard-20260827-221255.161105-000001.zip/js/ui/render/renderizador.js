(function(global){
'use strict';

/* =========================================================
   Renderizador do documento (React.createElement)
   ========================================================= */

const { extrairVariaveis, obterTextoModelo } = window.EDM_XmlParser;
const { avaliarExpressao, extrairVariaveisDaExpressao } = window.EDM_Expressoes;
const { obterTooltipCampo } = window.EDM_Modelo;
const EDM_AOP = window.EDM_Eventos.AOP;
const { resetRenderKeys, getNextKey, isElementoBloco } = window.EDM_Utils;

// Acesso preguiçoso evita dependência circular entre renderizador e realce.
function textoComDestaque(...args){ return window.EDM_Realce.textoComDestaque(...args); }

function criarContextoNumeracao(prefixo='',habilitado=false){
    return {prefixo,next:1,lastNumber:prefixo||'',habilitado,numerarBlocos:false};
}

function proximoNumero(contexto){
    if(!contexto||!contexto.habilitado)return null;
    const numero=contexto.prefixo?`${contexto.prefixo}.${contexto.next}`:String(contexto.next);
    contexto.next++;
    contexto.lastNumber=numero;
    return numero;
}

function proximoNumeroSemConsumir(contexto){
    if(!contexto||!contexto.habilitado)return null;
    return contexto.prefixo?`${contexto.prefixo}.${contexto.next}`:String(contexto.next);
}

function renderizarInlineComQuebras(node,dados,estrutura){
    if(!node)return [];

    if(node.tipo==='texto'){
        const texto=String(node.texto||'').replace(/\t/g,' ');
        const linhas=texto.split(/\r?\n/);
        const partes=[];

        linhas.forEach((linha,index)=>{
            if(index>0)partes.push({__edmBreak:true});
            if(linha!==''){
                const renderizados=textoComDestaque(linha,dados,estrutura);
                renderizados.forEach(item=>partes.push(item));
            }
        });

        return partes;
    }

    if(node.tipo==='b'||node.tipo==='i'||node.tipo==='u'){
        const tagReact=node.tipo==='b'?'strong':node.tipo==='i'?'em':'u';
        const partesFilhas=[];
        (node.filhos||[]).forEach(filho=>{
            partesFilhas.push(...renderizarInlineComQuebras(filho,dados,estrutura));
        });

        const resultado=[];
        let grupo=[];

        const fecharGrupo=()=>{
            if(!grupo.length)return;
            resultado.push(
                React.createElement(
                    tagReact,
                    {key:getNextKey()},
                    ...grupo
                )
            );
            grupo=[];
        };

        partesFilhas.forEach(parte=>{
            if(parte&&parte.__edmBreak){
                fecharGrupo();
                resultado.push(parte);
            }else if(parte!=null){
                grupo.push(parte);
            }
        });

        fecharGrupo();
        return resultado;
    }

    // Outros nós inline são renderizados normalmente.
    const renderizado=renderizarNo(node,dados,getNextKey(),'inline',estrutura,null);
    return renderizado==null?[]:(Array.isArray(renderizado)?renderizado:[renderizado]);
}

function renderizarConteudo(nodeList,dados,modo,estrutura,contextoNumeracao=null){
    if(modo==='inline'){
        const resultado=[];
        nodeList.forEach(node=>{
            const renderizado=renderizarNo(
                node,dados,getNextKey(),'inline',estrutura,contextoNumeracao
            );
            if(renderizado!=null){
                if(Array.isArray(renderizado))resultado.push(...renderizado);
                else resultado.push(renderizado);
            }
        });
        return resultado;
    }

    const elementos=[];
    let buffer=[];
    let bufferVars='';

    function adicionarVariaveis(vars){
        if(!vars)return;
        const existentes=new Set(bufferVars.split(',').filter(Boolean));
        vars.split(',').map(v=>v.trim()).filter(Boolean)
            .forEach(v=>existentes.add(v));
        bufferVars=Array.from(existentes).join(',');
    }

    function temConteudo(){
        return buffer.some(item=>{
            if(item&&item.__edmBreak)return false;
            if(typeof item==='string'){
                return item.replace(/\s+/g,' ').trim()!=='';
            }
            return item!=null && item!==false;
        });
    }

    function flush(){
        if(!temConteudo()){
            buffer=[];
            bufferVars='';
            return;
        }

        const numero=contextoNumeracao?.numerarBlocos
            ?proximoNumero(contextoNumeracao)
            :null;

        const conteudo=numero
            ?React.createElement(
                React.Fragment,
                null,
                React.createElement(
                    'span',
                    {className:'numero-secao'},
                    `${numero}. `
                ),
                ...buffer
            )
            :React.createElement(
                React.Fragment,
                null,
                ...buffer
            );

        elementos.push(
            React.createElement(
                'p',
                {
                    key:getNextKey(),
                    'data-vars':bufferVars,
                    className:numero?'paragrafo-numerado':''
                },
                conteudo
            )
        );

        buffer=[];
        bufferVars='';
    }

    function adicionarInline(node){
        const partes=renderizarInlineComQuebras(node,dados,estrutura);

        partes.forEach(parte=>{
            if(parte&&parte.__edmBreak){
                // Uma quebra de linha no XML representa o fim do
                // parágrafo. Quebras contendo somente indentação não
                // criam parágrafos vazios porque flush() verifica
                // temConteudo().
                flush();
                return;
            }

            if(typeof parte==='string'){
                if(parte!==''){
                    buffer.push(parte);
                    adicionarVariaveis(extrairVariaveis(parte));
                }
                return;
            }

            if(parte!=null && parte!==false){
                buffer.push(parte);
                if(parte.props?.['data-vars']){
                    adicionarVariaveis(parte.props['data-vars']);
                }
            }
        });
    }

    nodeList.forEach(node=>{
        if(!node)return;

        const tag=node.tipo;

        if(tag==='texto'){
            adicionarInline(node);
            return;
        }

        if(isElementoBloco(tag)){
            flush();

            const renderizado=renderizarNo(
                node,dados,getNextKey(),'bloco',estrutura,contextoNumeracao
            );

            if(renderizado!=null){
                if(Array.isArray(renderizado))elementos.push(...renderizado);
                else elementos.push(renderizado);
            }
            return;
        }

        // b, i, u e demais elementos inline.
        adicionarInline(node);
    });

    flush();
    return elementos;
}

function formatarItemForeach(valor){
    let texto=String(valor??'').trim();

    if(texto.length>=2){
        const primeiro=texto[0];
        const ultimo=texto[texto.length-1];

        if((primeiro==='"'&&ultimo==='"')||(primeiro==="'"&&ultimo==="'")){
            texto=texto.slice(1,-1).trim();
        }
    }

    return texto;
}

function renderizarNo(node,dados,key,modo,estrutura,contextoNumeracao=null){
    if(!node)return null;

    if(node.tipo==='texto'){
        const texto=node.texto||'';
        if(modo==='inline')return textoComDestaque(texto.replace(/\t/g,' '),dados,estrutura);
        return textoComDestaque(texto.replace(/\t/g,' '),dados,estrutura);
    }

    const tag=node.tipo;
    const filhos=node.filhos||[];

    if(tag==='secao'){
        const titulo=String(node.atributos?.titulo||'').trim();
        const numerar=node.atributos?.numerar!=='false';
        const tituloVisivel=titulo!=='';
        const elementos=[];

        /*
         * Uma seção com título consome um número do nível atual.
         * Primeiro renderizamos os filhos em um contexto de teste.
         * Só depois confirmamos o número no contexto pai. Assim:
         *
         *   <if> falso
         *   <secao> vazia
         *
         * nunca deixam um número "reservado" e vazio.
         *
         * Uma seção SEM título é um nível invisível: ela não consome
         * número próprio. Seus filhos passam a usar como prefixo o
         * último item efetivamente gerado no nível pai.
         */
        let numero=null;
        let contextoFilhos;

        if(tituloVisivel && numerar && contextoNumeracao?.habilitado){
            numero=proximoNumeroSemConsumir(contextoNumeracao);
            contextoFilhos=criarContextoNumeracao(numero,true);
            contextoFilhos.numerarBlocos=true;
        }else if(tituloVisivel && !numerar){
            contextoFilhos=criarContextoNumeracao('',false);
        }else if(!tituloVisivel){
            const prefixo=contextoNumeracao?.lastNumber||'';
            contextoFilhos=criarContextoNumeracao(prefixo,Boolean(prefixo));
            contextoFilhos.numerarBlocos=Boolean(prefixo);
        }else{
            contextoFilhos=criarContextoNumeracao('',false);
        }

        const filhosRenderizados=renderizarConteudo(
            filhos,
            dados,
            'bloco',
            estrutura,
            contextoFilhos
        );

        const temConteudo=filhosRenderizados.length>0;

        /*
         * Se a seção possui título, o próprio título é conteúdo.
         * Se não possui título, só existe se algum filho realmente
         * produziu conteúdo.
         */
        if(tituloVisivel){
            if(numerar && contextoNumeracao?.habilitado && numero!==null){
                // O título da seção existe mesmo quando seus IFs não renderizam conteúdo.
                // Portanto, a seção sempre consome seu número e as próximas seguem 8, 9, 10...
                contextoNumeracao.next++;
                contextoNumeracao.lastNumber=numero;
            }

            const textoTitulo=numero?`${numero}. ${titulo}`:titulo;
            elementos.push(
                React.createElement(
                    'h2',
                    {
                        key:getNextKey(),
                        className:numero?'secao-titulo numerado':'secao-titulo',
                        'data-secao-numero':numero||undefined
                    },
                    ...textoComDestaque(textoTitulo,dados,estrutura)
                )
            );
        }else if(!temConteudo){
            // Seção invisível e vazia: não gera nada e não altera a numeração.
            return [];
        }

        elementos.push(...filhosRenderizados);
        return elementos;
    }

    if(tag==='titulo'){
        const texto=obterTextoModelo(node);

        return React.createElement(
            'h2',
            {key,'data-vars':extrairVariaveis(texto)},
            ...textoComDestaque(texto.trim(),dados,estrutura)
        );
    }

    if(tag==='subtitulo'){
        const texto=obterTextoModelo(node);

        return React.createElement(
            'h3',
            {key,'data-vars':extrairVariaveis(texto)},
            ...textoComDestaque(texto.trim(),dados,estrutura)
        );
    }

    if(tag==='p'||tag==='paragrafo'){
        const conteudo=renderizarConteudo(filhos,dados,'inline',estrutura);
        if(!conteudo.some(item=>{
            if(item==null||item===false)return false;
            if(typeof item==='string')return item.replace(/\s+/g,'').length>0;
            if(item?.props?.children!=null){
                const filhosItem=Array.isArray(item.props.children)?item.props.children:[item.props.children];
                return filhosItem.some(v=>typeof v==='string'?v.replace(/\s+/g,'').length>0:v!=null&&v!==false);
            }
            return true;
        }))return null;
        return React.createElement(
            'p',
            {key,'data-vars':extrairVariaveis(obterTextoModelo(node))},
            ...conteudo
        );
    }

    if(tag==='b'||tag==='i'||tag==='u'){
        const tagReact=tag==='b'?'strong':tag==='i'?'em':'u';

        return React.createElement(
            tagReact,
            {key},
            ...renderizarConteudo(filhos,dados,'inline',estrutura)
        );
    }

    if(tag==='item'){
        return React.createElement(
            'li',
            {key,'data-vars':extrairVariaveis(obterTextoModelo(node))},
            ...renderizarConteudo(filhos,dados,'inline',estrutura)
        );
    }

    if(tag==='lista'){
        const numerada=node.atributos?.numerada==='true';
        const tagLista=numerada?'ol':'ul';
        const itens=[];

        const valoresDaLista=valor=>{
            if(Array.isArray(valor))return valor.map(v=>String(v).trim()).filter(Boolean);

            const texto=String(valor??'');
            const itens=[];
            let atual='';
            let aspas=null;
            let inicioItem=true;

            const adicionar=()=>{
                const item=atual.trim();
                if(item)itens.push(item);
                atual='';
                inicioItem=true;
            };

            for(let i=0;i<texto.length;i++){
                const ch=texto[i];

                if(aspas===null && (ch==='\r' || ch==='\n')){
                    if(ch==='\r' && texto[i+1]==='\n')i++;
                    adicionar();
                    continue;
                }

                // Ignora espaços no começo do item.
                if(aspas===null && inicioItem && /\s/.test(ch))continue;

                // Aspas só delimitam um item quando aparecem no início.
                if(aspas===null && inicioItem && (ch==='"' || ch==="'")){
                    aspas=ch;
                    inicioItem=false;
                    continue;
                }

                // Fecha as aspas do item atual.
                if(aspas!==null && ch===aspas){
                    // Só fecha se, daqui até o próximo separador, houver
                    // apenas espaços. Assim a aspa realmente é delimitadora.
                    let j=i+1;
                    while(j<texto.length && (texto[j]===' ' || texto[j]==='\t'))j++;
                    if(j===texto.length || texto[j]===',' || texto[j]==='\r' || texto[j]==='\n'){
                        aspas=null;
                        continue;
                    }
                }

                if(aspas===null && ch===','){
                    adicionar();
                    continue;
                }

                atual+=ch;
                if(!/\s/.test(ch))inicioItem=false;
            }

            adicionar();
            return itens;
        };

        function coletarItens(nodes,dadosAtuais){
            nodes.forEach(child=>{
                if(!child||!child.tipo)return;

                if(child.tipo==='item'){
                    const conteudoItem=renderizarConteudo(
                        child.filhos||[],
                        dadosAtuais,
                        'inline',
                        estrutura
                    );
                    const variaveisItem=extrairVariaveis(obterTextoModelo(child)).split(',').map(v=>v.trim()).filter(Boolean);
                    const origemId=variaveisItem.map(v=>dadosAtuais.__edmListaOrigem?.[v]).find(Boolean);
                    itens.push(
                        React.createElement(
                            'li',
                            {
                                key:getNextKey(),
                                'data-vars':extrairVariaveis(obterTextoModelo(child)),
                                title:origemId?`Clique para localizar: ${obterTooltipCampo(estrutura.grupos,estrutura.campos,origemId)}`:undefined,
                                onClick:e=>{
                                    if(origemId){
                                        e.stopPropagation();
                                        EDM_AOP.interagir(origemId,'documento');
                                    }
                                }
                            },
                            ...conteudoItem
                        )
                    );
                    return;
                }

                if(child.tipo==='foreach'){
                    const varName=child.atributos?.var;
                    const listaNome=child.atributos?.lista;
                    if(!varName||!listaNome)return;

                    valoresDaLista(dadosAtuais[listaNome]).forEach(valor=>{
                        const contexto={
                            ...dadosAtuais,
                            [varName]:formatarItemForeach(valor),
                            __edmListaOrigem:{
                                ...(dadosAtuais.__edmListaOrigem||{}),
                                [varName]:listaNome
                            }
                        };
                        coletarItens(child.filhos||[],contexto);
                    });
                    return;
                }

                if(child.tipo==='if'){
                    const expr=child.atributos?.expr;
                    if(expr&&avaliarExpressao(expr,dadosAtuais))coletarItens(child.filhos||[],dadosAtuais);
                }
            });
        }

        coletarItens(filhos,dados);
        return React.createElement(tagLista,{key},...itens);
    }

    if(tag==='tabela'){
        const linhas=[];

        filhos.forEach((linhaNode,linhaIndex)=>{
            const tipo=linhaNode.tipo;

            if(tipo!=='cabecalho'&&tipo!=='linha')return;

            const celulas=[];

            (linhaNode.filhos||[]).forEach((celulaNode,celulaIndex)=>{
                if(celulaNode.tipo!=='celula')return;

                const tipoCelula=tipo==='cabecalho'?'th':'td';

                celulas.push(
                    React.createElement(
                        tipoCelula,
                        {
                            key:`${key}-c-${linhaIndex}-${celulaIndex}`,
                            'data-vars':extrairVariaveis(obterTextoModelo(celulaNode))
                        },
                        ...renderizarConteudo(celulaNode.filhos||[],dados,'inline',estrutura)
                    )
                );
            });

            if(celulas.length>0){
                linhas.push(
                    React.createElement('tr',{key:`${key}-l-${linhaIndex}`},...celulas)
                );
            }
        });

        return React.createElement(
            'table',
            {key},
            React.createElement('tbody',null,...linhas)
        );
    }

    if(tag==='foreach'){
        const varName=node.atributos?.var;
        const listaNome=node.atributos?.lista;

        if(!varName||!listaNome)return null;

        const valores=valoresDaLista(dados[listaNome]);

        const elementos=[];

        valores.forEach(valor=>{
            const novosDados={
                ...dados,
                [varName]:formatarItemForeach(valor),
                __edmListaOrigem:{
                    ...(dados.__edmListaOrigem||{}),
                    [varName]:listaNome
                }
            };

            const filhosRenderizados=renderizarConteudo(
                filhos,
                novosDados,
                modo,
                estrutura
            );

            elementos.push(...filhosRenderizados);
        });

        return elementos;
    }

    if(tag==='if'){
        const expr=node.atributos?.expr;

        if(!expr||!avaliarExpressao(expr,dados)){
            return null;
        }

        const vars=extrairVariaveisDaExpressao(expr);
        const primeiraVariavel=vars.split(',').map(v=>v.trim()).filter(Boolean)[0];
        const caminho=primeiraVariavel?obterTooltipCampo(estrutura.grupos,estrutura.campos,primeiraVariavel):expr;

        const marcador=React.createElement(
            'span',
            {
                key:`${key}-marker`,
                'data-vars':vars,
                style:{
                    display:'inline-block',
                    width:0,
                    height:0,
                    overflow:'hidden',
                    margin:0,
                    padding:0,
                    border:0,
                    fontSize:0,
                    lineHeight:0
                }
            }
        );

        const focoIf=()=>{
            if(window.edmIrParaCampo===false)return;
            const ids=vars.split(',').map(v=>v.trim()).filter(Boolean);
            const id=ids[0];
            if(id)EDM_AOP.interagir(id,'documento');
        };

        const conteudoIf=React.createElement(
            'div',
            {
                key:`${key}-if`,
                className:'if-destaque if-interativo',
                'data-vars':vars,
                'data-caminho':caminho,
                'data-tooltip':caminho,
                title:`Clique para localizar o campo que controla esta condição: ${caminho}`,
                onClick:e=>{
                    e.stopPropagation();
                    focoIf();
                }
            },
            ...renderizarConteudo(filhos,dados,'bloco',estrutura)
        );

        return[marcador,conteudoIf];
    }

    return renderizarConteudo(filhos,dados,modo,estrutura);
}

global.EDM_Render = {
    resetRenderKeys,
    getNextKey,
    isElementoBloco,
    criarContextoNumeracao,
    proximoNumero,
    proximoNumeroSemConsumir,
    renderizarInlineComQuebras,
    renderizarConteudo,
    formatarItemForeach,
    renderizarNo
};
})(window);
