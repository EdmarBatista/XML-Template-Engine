(function(){
/* =========================================================
   Bootstrap: monta o React no #root
   ========================================================= */
const {
  ConfigProvider
} = window.EDM_Config;
const {
  App
} = window.EDM_UI_App;
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(/*#__PURE__*/React.createElement(ConfigProvider, null, /*#__PURE__*/React.createElement(App, null)));
})();
