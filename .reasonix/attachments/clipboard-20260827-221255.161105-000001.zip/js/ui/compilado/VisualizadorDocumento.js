(function(){
/* =========================================================
   Visualizador do documento
   ========================================================= */
const {
  useConfig
} = window.EDM_Config;
const {
  renderizarConteudo,
  criarContextoNumeracao,
  resetRenderKeys
} = window.EDM_Render;
const EDM_AOP = window.EDM_Eventos.AOP;
function VisualizadorDocumento({
  conteudo,
  dados,
  campoAlterado,
  campoAlteradoVersao,
  origemCampoAlterado,
  estrutura
}) {
  const {
    deslocarDocumento,
    numeracaoAtiva
  } = useConfig();
  const ref = React.useRef(null);
  const [dadosVersao, setDadosVersao] = React.useState(0);
  const destaques = React.useRef(new Map());
  const timers = React.useRef(new Map());
  React.useEffect(() => {
    const atualizar = () => setDadosVersao(v => v + 1);
    window.addEventListener('edm:configuracao', atualizar);
    return () => window.removeEventListener('edm:configuracao', atualizar);
  }, []);
  const elementos = React.useMemo(() => {
    resetRenderKeys();
    return renderizarConteudo(conteudo.filhos, dados, 'bloco', estrutura, criarContextoNumeracao('', numeracaoAtiva));
  }, [conteudo, dados, estrutura, dadosVersao, numeracaoAtiva]);
  React.useEffect(() => {
    const selecionar = id => Array.from(ref.current?.querySelectorAll('.variavel-interativa[data-vars],.if-destaque[data-vars]') || []).filter(el => (el.getAttribute('data-vars') || '').split(',').map(v => v.trim()).includes(id));
    const reaplicar = () => {
      const agora = Date.now();
      destaques.current.forEach((fim, id) => {
        if (fim <= agora) destaques.current.delete(id);
      });
      const ids = [...destaques.current.keys()];
      (ref.current?.querySelectorAll('.variavel-interativa[data-vars],.if-destaque[data-vars]') || []).forEach(el => {
        const vars = (el.getAttribute('data-vars') || '').split(',').map(v => v.trim());
        el.classList.toggle('edm-texto-alterado', vars.some(id => ids.includes(id)));
      });
    };
    const destacar = ({
      id
    }) => {
      const fim = Date.now() + 5000;
      destaques.current.set(id, fim);
      const anterior = timers.current.get(id);
      if (anterior) clearTimeout(anterior);
      selecionar(id).forEach(el => el.classList.add('edm-texto-alterado'));
      const timer = setTimeout(() => {
        destaques.current.delete(id);
        selecionar(id).forEach(el => el.classList.remove('edm-texto-alterado'));
        timers.current.delete(id);
      }, 5000);
      timers.current.set(id, timer);
    };
    const deslocar = ({
      id,
      origem
    }) => {
      // Cliques na coluna direita (documento) só devem deslocar para o campo,
      // não para a primeira ocorrência do elemento no documento.
      if (origem === 'inline' || origem === 'variavel' || origem === 'documento' || deslocarDocumento === false) return;
      selecionar(id)[0]?.scrollIntoView({
        behavior: 'smooth',
        block: 'center',
        inline: 'nearest'
      });
    };
    const offDestaque = EDM_AOP.on('interacao', destacar);
    const offDeslocamento = EDM_AOP.on('interacao', deslocar);
    const frame = requestAnimationFrame(reaplicar);
    return () => {
      offDestaque();
      offDeslocamento();
      cancelAnimationFrame(frame);
      timers.current.forEach(clearTimeout);
      timers.current.clear();
    };
  }, [deslocarDocumento]);
  React.useEffect(() => {
    if (campoAlterado) EDM_AOP.interagir(String(campoAlterado), origemCampoAlterado || 'painel');
  }, [campoAlterado, campoAlteradoVersao, origemCampoAlterado, deslocarDocumento]);
  React.useEffect(() => {
    const reaplicar = () => {
      const agora = Date.now();
      const ativos = new Set();
      destaques.current.forEach((fim, id) => fim > agora ? ativos.add(id) : destaques.current.delete(id));
      (ref.current?.querySelectorAll('.variavel-interativa[data-vars],.if-destaque[data-vars]') || []).forEach(el => {
        const vars = (el.getAttribute('data-vars') || '').split(',').map(v => v.trim());
        el.classList.toggle('edm-texto-alterado', vars.some(id => ativos.has(id)));
      });
    };
    const frame = requestAnimationFrame(reaplicar);
    return () => cancelAnimationFrame(frame);
  }, [dados, dadosVersao]);
  return /*#__PURE__*/React.createElement("main", {
    className: "document-area",
    ref: ref
  }, /*#__PURE__*/React.createElement("article", {
    className: "document"
  }, elementos));
}
window.EDM_UI_VisualizadorDocumento = VisualizadorDocumento;
})();
