(function(){
/* =========================================================
   Realce / edição inline de variáveis (React)
   ========================================================= */

const {
  campoValido,
  aplicarFiltro,
  aplicarMascaraCampo
} = window.EDM_Validacao;
const {
  obterTooltipCampo
} = window.EDM_Modelo;
const {
  getNextKey
} = window.EDM_Utils;
const EDM_AOP = window.EDM_Eventos.AOP;
const {
  useConfig
} = window.EDM_Config;
const {
  VariavelInterativa,
  textoComDestaque
} = function () {
  function VariavelInterativa({
    id,
    valorExibido,
    valorBruto,
    filtro,
    caminho,
    estrutura,
    token,
    listaForeach = false
  }) {
    const {
      edicaoInline,
      irParaCampo
    } = useConfig();
    const campo = estrutura?.campos?.[id] || {};
    const tipo = String(campo.tipo || 'input').toLowerCase();
    const opcoes = Array.isArray(campo.opcoes) ? campo.opcoes : [];
    const ehRadio = tipo === 'radio';
    const ehListaForeach = listaForeach;
    const [corrigindo, setCorrigindo] = React.useState(false);
    const [valor, setValor] = React.useState(valorBruto ?? '');
    const [invalido, setInvalido] = React.useState(false);
    const timerRef = React.useRef(null);
    const radioRef = React.useRef(null);
    React.useEffect(() => {
      if (!corrigindo) {
        setValor(valorBruto ?? '');
        setInvalido(false);
      }
    }, [valorBruto, corrigindo]);

    // Mantém a edição do radio aberta enquanto o usuário troca de opção.
    // O editor só é encerrado quando o clique acontece fora do grupo.
    React.useEffect(() => {
      if (!corrigindo || !ehRadio) return;
      const aoClicarFora = e => {
        const editor = radioRef.current;
        if (editor && !editor.contains(e.target)) {
          salvar();
        }
      };
      document.addEventListener('pointerdown', aoClicarFora, true);
      return () => document.removeEventListener('pointerdown', aoClicarFora, true);
    }, [corrigindo, ehRadio, valorBruto, valor]);
    const salvar = (valorParaSalvar = valor) => {
      if (!campoValido(campo, valorParaSalvar)) {
        setInvalido(true);
        return false;
      }
      const novo = tipo === 'checkbox' ? Boolean(valorParaSalvar) : String(valorParaSalvar ?? '');
      const antigo = tipo === 'checkbox' ? Boolean(valorBruto) : String(valorBruto ?? '');
      if (novo !== antigo) {
        const fn = window.edmAtualizarCampo;
        if (fn) fn(id, novo, 'inline');
      }
      setCorrigindo(false);
      setInvalido(false);
      return true;
    };

    // Comportamento da versão antiga que funcionava:
    // clicar em uma opção atualiza o valor, mas NÃO fecha o editor.
    const salvarRadio = opcao => {
      const novoValor = String(opcao);
      if (!opcoes.some(op => String(op) === novoValor)) {
        return;
      }

      // A seleção fica localmente pendente.
      // A confirmação ocorre somente ao clicar fora.
      setValor(novoValor);
      setInvalido(false);
    };
    const cancelar = () => {
      setValor(valorBruto ?? '');
      setInvalido(false);
      setCorrigindo(false);
    };
    const focarEsquerda = () => {
      EDM_AOP.interagir(id, 'documento');
    };
    const iniciarEdicao = e => {
      e.preventDefault();
      e.stopPropagation();
      if (timerRef.current) {
        clearTimeout(timerRef.current);
        timerRef.current = null;
      }
      if (edicaoInline === false) return;
      setValor(valorBruto ?? '');
      setInvalido(false);
      setCorrigindo(true);
    };
    const clique = e => {
      e.stopPropagation();
      if (timerRef.current) clearTimeout(timerRef.current);
      if (e.detail >= 2) return;
      const alvo = e.currentTarget;
      timerRef.current = setTimeout(() => {
        timerRef.current = null;
        EDM_AOP.interagir(id, 'variavel');
      }, 260);
    };
    React.useEffect(() => () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    }, []);
    if (corrigindo) {
      if (ehRadio) {
        return React.createElement('span', {
          ref: radioRef,
          className: 'variavel-radio-editor variavel-interativa',
          'data-vars': id,
          'data-caminho': caminho,
          onClick: e => e.stopPropagation()
        }, opcoes.length ? opcoes.map((op, i) => React.createElement('label', {
          key: i
        }, React.createElement('input', {
          type: 'radio',
          name: `edm-inline-${id}`,
          value: String(op),
          checked: String(valor ?? '') === String(op),
          onChange: e => salvarRadio(e.target.value)
        }), String(op))) : React.createElement('span', {
          className: 'campo-erro'
        }, 'Nenhuma opção definida no XML.'));
      }
      const mascara = String(campo.tipoInput || '').toLowerCase();
      const ehMascara = ['moeda', 'cnpj', 'cep'].includes(mascara);
      const valorExibidoEditor = ehMascara ? aplicarMascaraCampo(valor, mascara) : valor === true ? 'true' : valor === false ? 'false' : String(valor ?? '');
      const comum = {
        className: `variavel-editor variavel-editando${invalido ? ' variavel-editor-invalido' : ''}`,
        value: valorExibidoEditor,
        autoFocus: true,
        onChange: e => {
          if (e.target.type === 'checkbox') {
            setValor(e.target.checked);
          } else if (ehMascara) {
            const valorFormatado = aplicarMascaraCampo(e.target.value, mascara);
            const valorBruto = window.DocumentoUtils?.normalizarValorCampo ? DocumentoUtils.normalizarValorCampo(valorFormatado, mascara) : valorFormatado;
            setValor(valorBruto);
          } else {
            setValor(e.target.value);
          }
          if (invalido) setInvalido(false);
        },
        onBlur: () => salvar(),
        onKeyDown: e => {
          if (e.key === 'Enter' && tipo !== 'textarea') {
            e.preventDefault();
            salvar();
          }
          if (e.key === 'Escape') {
            e.preventDefault();
            cancelar();
          }
        },
        onClick: e => e.stopPropagation(),
        title: invalido ? 'Valor inválido.' : `Editar ${caminho}`
      };
      if (tipo === 'select') {
        return React.createElement('select', {
          ...comum,
          value: String(valor ?? '')
        }, React.createElement('option', {
          value: ''
        }, 'Selecione...'), ...opcoes.map((op, i) => React.createElement('option', {
          key: i,
          value: String(op)
        }, String(op))));
      }
      if (tipo === 'textarea' || ehListaForeach) {
        return React.createElement('textarea', {
          className: `variavel-editor variavel-editando${invalido ? ' variavel-editor-invalido' : ''}${ehListaForeach ? ' edm-lista-foreach' : ''}`,
          value: String(valor ?? ''),
          autoFocus: true,
          rows: Math.max(2, String(valor ?? '').split('\\n').length),
          onChange: e => {
            setValor(e.target.value);
            if (invalido) setInvalido(false);
            requestAnimationFrame(() => {
              e.target.style.height = 'auto';
              e.target.style.height = e.target.scrollHeight + 'px';
            });
          },
          onBlur: () => salvar(),
          onKeyDown: e => {
            if (e.key === 'Escape') {
              e.preventDefault();
              cancelar();
            }
          },
          onClick: e => e.stopPropagation(),
          ref: el => {
            if (el) {
              el.style.height = 'auto';
              el.style.height = el.scrollHeight + 'px';
            }
          }
        });
      }
      if (tipo === 'checkbox') {
        return React.createElement('input', {
          ...comum,
          type: 'checkbox',
          checked: valor === true
        });
      }
      return React.createElement('input', {
        ...comum,
        type: ehMascara ? 'text' : tipo === 'date' ? 'date' : tipo === 'number' ? 'number' : campo.tipoInput || 'text',
        inputMode: ehMascara ? 'numeric' : undefined,
        placeholder: campo.placeholder || ''
      });
    }
    const podeLocalizar = irParaCampo !== false;
    const podeEditar = edicaoInline !== false;
    const tituloInteracao = podeLocalizar && podeEditar ? 'Clique para localizar o campo. Duplo clique para editar aqui.' : podeLocalizar ? 'Clique para localizar o campo.' : podeEditar ? 'Duplo clique para editar aqui.' : '';
    return React.createElement('span', {
      key: token,
      className: 'destaque com-caminho variavel-interativa',
      'data-vars': id,
      'data-caminho': caminho,
      'data-tooltip': caminho,
      title: tituloInteracao || undefined,
      onClick: clique,
      onDoubleClick: iniciarEdicao
    }, valorExibido !== '' || valorExibido === 0 ? String(valorExibido) : `{{${id}${filtro ? ' | ' + filtro : ''}}}`);
  }
  function textoComDestaque(textoOriginal, dados, estrutura) {
    const regex = /\{\{(\w+)(?:\s*\|\s*(\w+))?\}\}/g;
    const partes = [];
    let lastIndex = 0;
    let match;
    while ((match = regex.exec(textoOriginal)) !== null) {
      if (match.index > lastIndex) partes.push(textoOriginal.substring(lastIndex, match.index));
      const chave = match[1];
      const filtro = match[2] || null;
      const valorBruto = dados[chave] !== undefined ? dados[chave] : '';
      const campoOrigem = dados.__edmListaOrigem?.[chave] || chave;

      // Dentro de um foreach, "chave" é apenas o item corrente.
      // Para edição inline, porém, o usuário deve editar a lista
      // original completa. Assim, ao abrir qualquer item, o editor
      // recebe "item1,item2,item3", e não somente "item2".
      const valorBrutoEdicao = campoOrigem !== chave && dados[campoOrigem] !== undefined ? dados[campoOrigem] : valorBruto;
      const valor = filtro ? aplicarFiltro(valorBruto, filtro) : valorBruto;
      const caminho = obterTooltipCampo(estrutura.grupos, estrutura.campos, campoOrigem);
      partes.push(/*#__PURE__*/React.createElement(VariavelInterativa, {
        key: getNextKey(),
        id: campoOrigem,
        valorExibido: valor,
        valorBruto: valorBrutoEdicao,
        filtro: filtro,
        caminho: caminho,
        estrutura: estrutura,
        token: getNextKey(),
        listaForeach: campoOrigem !== chave
      }));
      lastIndex = match.index + match[0].length;
    }
    if (lastIndex < textoOriginal.length) partes.push(textoOriginal.substring(lastIndex));
    return partes.length > 0 ? partes : [textoOriginal];
  }
  return {
    VariavelInterativa,
    textoComDestaque
  };
}();
window.EDM_Realce = {
  VariavelInterativa,
  textoComDestaque
};
})();
