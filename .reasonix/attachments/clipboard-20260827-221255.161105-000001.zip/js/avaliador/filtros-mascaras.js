(function(global){
'use strict';

/* =========================================================
   Filtros, máscaras e validação de campos (EDM)
   ========================================================= */

function aplicarFiltro(valor,filtro){
    if(!valor&&valor!==0)return '';

    if(window.DocumentoUtils){
        return DocumentoUtils.aplicarFiltroDocumento(valor,filtro);
    }

    switch(filtro){
        case 'moeda':{
            const num=parseFloat(valor);
            return isNaN(num)?valor:'R$ '+num.toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2});
        }
        case 'data':
            return typeof valor==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(valor)?(()=>{
                const[ano,mes,dia]=valor.split('-');
                return `${dia}/${mes}/${ano}`;
            })():valor;
        case 'dataExtenso':return window.dataPorExtenso?.(valor)??valor;
        case 'extenso':
        case 'numeroExtenso':
        case 'numero_extenso':
        case 'numeroPorExtenso':return window.numeroPorExtenso?.(valor)??valor;
        case 'romano':return window.converterParaRomano?.(valor)??valor;
        case 'cnpj':return window.formatarCNPJ?.(valor)??valor;
        case 'cep':return window.formatarCEP?.(valor)??valor;
        default:return valor;
    }
}

function aplicarMascaraCampo(valor,mascara){
    if(!mascara)return valor??'';
    const nome=String(mascara).toLowerCase();
    if(nome==='cnpj')return window.formatarCNPJ?.(valor)??valor;
    if(nome==='cep')return window.formatarCEP?.(valor)??valor;
    if(nome==='moeda')return window.formatarMoeda?.(valor)??valor;
    return valor??'';
}

function normalizarDigitos(valor){
    return String(valor??'').replace(/\D/g,'');
}

function validarCNPJ(valor){
    const cnpj=normalizarDigitos(valor);
    if(!cnpj)return true;
    if(cnpj.length!==14)return false;
    if(/^([0-9])\1{13}$/.test(cnpj))return false;

    let soma=0,peso=5;
    for(let i=0;i<12;i++){
        soma+=Number(cnpj[i])*peso;
        peso=peso===2?9:peso-1;
    }
    let digito=soma%11;
    digito=digito<2?0:11-digito;
    if(digito!==Number(cnpj[12]))return false;

    soma=0;
    peso=6;
    for(let i=0;i<13;i++){
        soma+=Number(cnpj[i])*peso;
        peso=peso===2?9:peso-1;
    }
    digito=soma%11;
    digito=digito<2?0:11-digito;

    return digito===Number(cnpj[13]);
}

function validarCEP(valor){
    const cep=normalizarDigitos(valor);
    return !cep||cep.length===8;
}

function campoValido(campo,valor){
    const validar=String(campo?.validar||campo?.tipoInput||'').toLowerCase();
    if(validar==='email')return !valor||Boolean(window.validarEmail?.(valor));
    if(validar==='cnpj')return validarCNPJ(valor);
    if(validar==='cep')return validarCEP(valor);
    return true;
}

global.EDM_Validacao = {
    aplicarFiltro,
    aplicarMascaraCampo,
    normalizarDigitos,
    validarCNPJ,
    validarCEP,
    campoValido
};
})(window);
