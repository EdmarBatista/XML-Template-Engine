(function(global){
'use strict';

/* =========================================================
   Avaliador de expressões (if) do documento
   ========================================================= */

function extrairVariaveisDaExpressao(expr){
    return expr.replace(/'[^']*'/g,'').replace(/"[^"]*"/g,'').replace(/[=!<>]+/g,' ').replace(/\d+/g,' ').split(/\s+/).filter(token=>/^[a-zA-Z_]\w*$/.test(token)).join(',');
}

function dividirExpressao(expr,operador){
    let aspas=null,nivel=0;
    for(let i=0;i<=expr.length-operador.length;i++){
        const c=expr[i];
        if(c==="'"||c==='"'){if(aspas===c&&expr[i-1]!=="\\")aspas=null;else if(!aspas)aspas=c;continue}
        if(aspas)continue;
        if(c==='(')nivel++;else if(c===')')nivel--;
        if(nivel===0&&expr.slice(i,i+operador.length)===operador)return[expr.slice(0,i).trim(),expr.slice(i+operador.length).trim()];
    }
    return null;
}
function avaliarComparacao(expr,dados){
    expr=expr.trim().replace(/^\((.*)\)$/,'$1').trim();
    const match=expr.match(/^(\w+)\s*(==|!=|>=|<=|>|<)\s*(.+)$/);
    if(!match)return false;
    const[,varName,operator,rawValue]=match;
    const leftValue=dados[varName]!==undefined?dados[varName]:'';
    let rightValue=rawValue.trim();
    if((rightValue.startsWith("'")&&rightValue.endsWith("'"))||(rightValue.startsWith('"')&&rightValue.endsWith('"')))rightValue=rightValue.slice(1,-1);
    else if(rightValue==='true')rightValue=true;else if(rightValue==='false')rightValue=false;else if(rightValue!==''&&!isNaN(rightValue))rightValue=Number(rightValue);
    switch(operator){case '==':return leftValue==rightValue;case '!=':return leftValue!=rightValue;case '>':return Number(leftValue)>Number(rightValue);case '<':return Number(leftValue)<Number(rightValue);case '>=':return Number(leftValue)>=Number(rightValue);case '<=':return Number(leftValue)<=Number(rightValue);default:return false}
}
function avaliarExpressao(expr,dados){
    expr=String(expr||'').trim();
    const ou=dividirExpressao(expr,'||');if(ou)return avaliarExpressao(ou[0],dados)||avaliarExpressao(ou[1],dados);
    const e=dividirExpressao(expr,'&&');if(e)return avaliarExpressao(e[0],dados)&&avaliarExpressao(e[1],dados);
    return avaliarComparacao(expr,dados);
}

global.EDM_Expressoes = {
    extrairVariaveisDaExpressao,
    dividirExpressao,
    avaliarComparacao,
    avaliarExpressao
};
})(window);
