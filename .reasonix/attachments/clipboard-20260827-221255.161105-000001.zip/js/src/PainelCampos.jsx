/* =========================================================
   Painel de campos (sidebar)
   ========================================================= */
const { useConfig } = window.EDM_Config;
const { aplicarMascaraCampo, campoValido, normalizarDigitos, validarCNPJ } = window.EDM_Validacao;
const { normalizarNomeXml, chaveXml, baixarPreenchimentoJSON, toast } = window.EDM_Utils;
const {
    storage: EDM_STORAGE,
    EDM_SECTIONS_STORAGE_KEY,
    carregarEstadoSecoes, salvarEstadoSecoes
} = window.EDM_Storage;
const EDM_AOP = window.EDM_Eventos.AOP;
const { consultarCNPJ, consultarCEP, criarDebounce } = window.EDM_Api;

function PainelCampos({grupos,campos,listaCampos=new Set(),xmlName,dados,onChange,onFileUpload,onJsonUpload,collapsed,sidebarRef,onToggleMenu,onShowModel,onClear}){
    const {
        edicaoInline, setEdicaoInline,
        irParaCampo, setIrParaCampo,
        deslocarDocumento, setDeslocarDocumento,
        numeracaoAtiva, setNumeracaoAtiva,
        variaveisVermelhasWord, setVariaveisVermelhasWord,
        focoUsuarioPendente, setFocoPendente,
        focoRestaurado, setFocoResto,
        focosProgramaticos
    } = useConfig();

    const[secaoSelecionada,setSecaoSelecionada]=React.useState(0);
    const[secoesAbertas,setSecoesAbertas]=React.useState(()=>carregarEstadoSecoes(grupos,xmlName));
    const descricaoCampo=campo=>String(campo?.descricao||'').trim();

    const [consultaCNPJ,setConsultaCNPJ]=React.useState({chave:'',carregando:false,dados:null,erro:''});
    const [consultaCEP,setConsultaCEP]=React.useState({chave:'',carregando:false,dados:null,erro:''});

    /* Consultas com debounce + cancelamento. */
    const executarConsultaCNPJ=React.useCallback(cnpj=>{
        if(cnpj.length!==14||!validarCNPJ(cnpj)){
            setConsultaCNPJ({chave:cnpj,carregando:false,dados:null,erro:''});
            return;
        }
        setConsultaCNPJ(prev=>prev.chave===cnpj&&prev.dados?prev:{chave:cnpj,carregando:true,dados:null,erro:''});
        consultarCNPJ(cnpj).promessa
            .then(dadosApi=>setConsultaCNPJ({chave:cnpj,carregando:false,dados:dadosApi,erro:''}))
            .catch(()=>setConsultaCNPJ({chave:cnpj,carregando:false,dados:null,erro:'Não foi possível consultar o CNPJ.'}));
    },[]);

    const executarConsultaCEP=React.useCallback(cep=>{
        if(cep.length!==8){
            setConsultaCEP({chave:cep,carregando:false,dados:null,erro:''});
            return;
        }
        setConsultaCEP(prev=>prev.chave===cep&&prev.dados?prev:{chave:cep,carregando:true,dados:null,erro:''});
        consultarCEP(cep).promessa
            .then(dadosApi=>setConsultaCEP({chave:cep,carregando:false,dados:dadosApi,erro:''}))
            .catch(()=>setConsultaCEP({chave:cep,carregando:false,dados:null,erro:'Não foi possível consultar o CEP.'}));
    },[]);

    const debounceCNPJ=React.useMemo(()=>criarDebounce(executarConsultaCNPJ,400),[executarConsultaCNPJ]);
    const debounceCEP=React.useMemo(()=>criarDebounce(executarConsultaCEP,400),[executarConsultaCEP]);

    React.useEffect(()=>{
        debounceCNPJ(normalizarDigitos(dados?.cnpj));
    },[dados?.cnpj,debounceCNPJ]);

    React.useEffect(()=>{
        debounceCEP(normalizarDigitos(dados?.cep));
    },[dados?.cep,debounceCEP]);

    React.useEffect(()=>{
        const estado=carregarEstadoSecoes(grupos,xmlName);
        setSecoesAbertas(estado);
        const salvo=(()=>{try{const bruto=EDM_STORAGE.get(EDM_SECTIONS_STORAGE_KEY);const r=bruto?JSON.parse(bruto)||{}:{};return r[chaveXml(xmlName)]?.selecionada;}catch(error){return null;}})();
        setSecaoSelecionada(Number.isInteger(salvo)?salvo:0);
    },[grupos,xmlName]);

    React.useEffect(()=>{
        const focar=e=>{
            if(irParaCampo===false)return;
            const id=e.detail?.id;
            if(!id)return;
            const idx=grupos.findIndex(g=>g.campos?.includes(id));
            if(idx<0)return;
            if(collapsed){onToggleMenu?.();setTimeout(()=>window.dispatchEvent(new CustomEvent('edm:foco-campo',{detail:{id,origem:e.detail?.origem}})),180);return;}
            setSecaoSelecionada(idx);
            setSecoesAbertas(prev=>{
                const novo={...prev,[idx]:true};
                salvarEstadoSecoes(xmlName,novo,idx);
                return novo;
            });
            setTimeout(()=>{
                const container=document.querySelector(`[data-field-id="${CSS.escape(id)}"]`);
                if(!container)return;
                container.scrollIntoView({behavior:'smooth',block:'center'});
                const el=container.querySelector(`#${CSS.escape(id)},[name="${CSS.escape(id)}"],[name^="${CSS.escape(id)}-"]`);
                const alvo=el||container.querySelector('input,select,textarea');
                if(alvo){
                    if(e.detail?.origem==='documento'||e.detail?.origem==='variavel'){
                        focosProgramaticos.current.add(id);
                    }
                    alvo.focus({preventScroll:true});
                    setTimeout(()=>{
                        focosProgramaticos.current.delete(id);
                    },250);
                }
                container.classList.add('edm-campo-foco');
                setTimeout(()=>container.classList.remove('edm-campo-foco'),2500);
            },120);
        };
        const offAOP=EDM_AOP.on('interacao',({id,origem})=>{
            if((origem==='documento'||origem==='variavel')&&irParaCampo!==false)
                window.dispatchEvent(new CustomEvent('edm:foco-campo',{detail:{id,origem}}));
        });
        window.addEventListener('edm:foco-campo',focar);
        return()=>{offAOP();window.removeEventListener('edm:foco-campo',focar);};
    },[grupos,xmlName,collapsed,onToggleMenu,irParaCampo,focosProgramaticos]);

    const baixarJSON=()=>{
        baixarPreenchimentoJSON(xmlName,dados);
        toast('Preenchimento salvo em JSON.','sucesso');
    };

    const gerarWord=async()=>{
        try{
            const modeloWord={...(window.modelo||{}),dados};
            await WordEDM.gerarWord(modeloWord,`${normalizarNomeXml(xmlName).replace(/\.xml$/i,'')}.docx`,{ativarNumeracaoDocumento:numeracaoAtiva!==false,variaveisVermelhas:variaveisVermelhasWord===true});
            toast('Documento Word gerado com sucesso.','sucesso');
        }catch(error){
            console.error(error);
            toast(`Não foi possível gerar o Word: ${error.message}`,'erro');
        }
    };

    const alternar=(setter,nome)=>{
        setter(v=>{
            const novo=!v;
            try{EDM_STORAGE.set(nome,String(novo));}catch(error){}
            window.dispatchEvent(new Event('edm:configuracao'));
            return novo;
        });
    };

    return(
        <aside ref={sidebarRef} className={`sidebar ${collapsed?'collapsed':''}`}>
            <div className="sidebar-top">
                <div className="left-group">
                    <span className="sidebar-titulo" title={xmlName}>{xmlName}</span>
                    <label htmlFor="upload-xml" className="edm-tool-button btn-upload-xml" title="Abrir XML" aria-label="Abrir XML"><i className="fa-solid fa-folder-open" aria-hidden="true"></i></label>
                    <label htmlFor="upload-json" className="edm-tool-button" title="Carregar preenchimento JSON" aria-label="Carregar preenchimento JSON"><i className="fa-solid fa-file-import" aria-hidden="true"></i></label>
                    <input id="upload-json" type="file" accept=".json,application/json" onChange={onJsonUpload} hidden/>
                    <input id="upload-xml" type="file" accept=".xml" onChange={onFileUpload} hidden/>
                    <button type="button" className="edm-tool-button" title="Salvar preenchimento em JSON" aria-label="Salvar preenchimento em JSON" onClick={e=>{e.stopPropagation();baixarJSON();}}><i className="fa-solid fa-floppy-disk" aria-hidden="true"></i></button>
                    <button type="button" className="edm-tool-button" title="Salvar documento em Word" aria-label="Salvar documento em Word" onClick={e=>{e.stopPropagation();gerarWord();}}><span aria-hidden="true" className="edm-word-icon">W</span></button>
                    <button type="button" className={`edm-tool-button edm-left-setting ${variaveisVermelhasWord?'active':''}`} title={variaveisVermelhasWord?'Variáveis ficarão vermelhas no Word':'Deixar variáveis vermelhas no Word'} aria-label="Alternar variáveis vermelhas no Word" aria-pressed={variaveisVermelhasWord} onClick={e=>{e.stopPropagation();alternar(setVariaveisVermelhasWord,'edmVariaveisVermelhasWord');}}><i className="fa-solid fa-text-height" aria-hidden="true"></i></button>
                    
                    <button type="button" className={`edm-tool-button edm-left-setting ${edicaoInline?'':'desativado'}`} title="Habilitar ou desabilitar edição inline" aria-label="Habilitar ou desabilitar edição inline" aria-pressed={edicaoInline} onClick={e=>{e.stopPropagation();alternar(setEdicaoInline,'edmEdicaoInline');}}><i className="fa-solid fa-pen" aria-hidden="true"></i></button>
                    <button type="button" className={`edm-tool-button edm-left-setting ${deslocarDocumento?'':'desativado'}`} title="Habilitar ou desabilitar deslocamento do documento" aria-label="Habilitar ou desabilitar deslocamento do documento" aria-pressed={deslocarDocumento} onClick={e=>{e.stopPropagation();alternar(setDeslocarDocumento,'edmDeslocarDocumento');}}><i className="fa-solid fa-arrow-right-long" aria-hidden="true"></i></button>
                    <button type="button" className={`edm-tool-button edm-left-setting ${irParaCampo?'':'desativado'}`} title="Habilitar ou desabilitar deslocamento para o campo" aria-label="Habilitar ou desabilitar deslocamento para o campo" aria-pressed={irParaCampo} onClick={e=>{e.stopPropagation();alternar(setIrParaCampo,'edmIrParaCampo');}}><i className="fa-solid fa-arrow-left-long" aria-hidden="true"></i></button>
                    <button type="button" className={`edm-tool-button edm-left-setting ${numeracaoAtiva?'':'desativado'}`} title={numeracaoAtiva?'Desativar numeração do documento':'Ativar numeração do documento'} aria-label={numeracaoAtiva?'Desativar numeração do documento':'Ativar numeração do documento'} aria-pressed={numeracaoAtiva} onClick={e=>{e.stopPropagation();alternar(setNumeracaoAtiva,'edmNumeracaoAtiva');}}><i className="fa-solid fa-list-ol" aria-hidden="true"></i></button>
                    <button type="button" className="edm-tool-button" title="Variáveis e modelo" aria-label="Variáveis e modelo" onClick={e=>{e.stopPropagation();onShowModel?.();}}><i className="fa-solid fa-table-columns" aria-hidden="true"></i></button>
                    <button type="button" className="edm-tool-button" title={Object.values(secoesAbertas).some(Boolean)?"Recolher toda a árvore":"Expandir toda a árvore"} aria-label="Recolher ou expandir toda a árvore" onClick={e=>{e.stopPropagation();const abrir=!Object.values(secoesAbertas).some(Boolean);const novo=Object.fromEntries(grupos.map((_,i)=>[i,abrir]));setSecoesAbertas(novo);salvarEstadoSecoes(xmlName,novo,secaoSelecionada);}}><svg viewBox="0 0 24 24" aria-hidden="true">{Object.values(secoesAbertas).some(Boolean)?<><path d="M7 5l5 5 5-5"></path><path d="M7 19l5-5 5 5"></path></>:<><path d="M7 10l5-5 5 5"></path><path d="M7 14l5 5 5-5"></path></>}</svg></button>
                    <button type="button" className="edm-clear-button" title="Limpar preenchimento deste XML" aria-label="Limpar preenchimento deste XML" onClick={e=>{e.stopPropagation();if(confirm(`Limpar todos os campos de “${xmlName}”?`))onClear?.();}}><i className="fa-solid fa-trash" aria-hidden="true"></i></button>
                </div>
                <button className="collapse" title={collapsed?"Expandir coluna esquerda":"Minimizar coluna esquerda"} aria-label={collapsed?"Expandir coluna esquerda":"Minimizar coluna esquerda"} aria-expanded={!collapsed} onClick={e=>{e.stopPropagation();onToggleMenu();}}>
                    <i className={`fa-solid ${collapsed?'fa-chevron-right':'fa-chevron-left'}`} aria-hidden="true"></i>
                </button>
            </div>

            {grupos.map((grupo,idx)=>(
                <section key={idx} className={`section${secoesAbertas[idx]?' open':''}${secaoSelecionada===idx?' selected':''}`}>
                    <div className="section-header" onClick={()=>{
                        setSecoesAbertas(prev=>{
                            const novo={...prev,[idx]:!prev[idx]};
                            salvarEstadoSecoes(xmlName,novo,idx);
                            return novo;
                        });
                        setSecaoSelecionada(idx);
                    }}>
                        <span className="arrow"></span>
                        <span className="title">{grupo.titulo}</span>
                    </div>

                    <div className="section-body">
                        {grupo.campos.map(campoId=>{
                            const campo=campos[campoId];
                            const v=dados[campo.id]??'';

                            return(
                                <div key={campo.id} id={`campo-container-${campo.id}`} data-field-id={campo.id} className="field" title={descricaoCampo(campo)||undefined} onClick={()=>{
                                        setFocoPendente(false);
                                        setFocoResto(false);
                                        EDM_AOP.interagir(campo.id,'campo');
                                    }} onFocusCapture={()=>{
                                        if(focosProgramaticos.current.has(campo.id)){
                                            focosProgramaticos.current.delete(campo.id);
                                            return;
                                        }
                                        if(focoRestaurado&&!focoUsuarioPendente){
                                            setFocoResto(false);
                                            return;
                                        }
                                        if(!focoUsuarioPendente)return;
                                        setFocoPendente(false);
                                        EDM_AOP.interagir(campo.id,'campo');
                                    }}>
                                    {campo.tipo!=='checkbox'&&<label className="field-label" htmlFor={campo.id} title={descricaoCampo(campo)||undefined} onClick={e=>{e.stopPropagation();setFocoPendente(false);setFocoResto(false);EDM_AOP.interagir(campo.id,'campo');}}>{campo.label}</label>}

                                    {campo.tipo==='radio'
                                        ? null
                                        : listaCampos.has(campo.id)
                                            ? <textarea id={campo.id} value={v} rows={Math.max(4,String(v??'').split(/\\n/).length)} placeholder={String(v??'').trim()?'':descricaoCampo(campo)} title={descricaoCampo(campo)||undefined} onChange={e=>onChange(campo.id,e.target.value)}/>
                                            : campo.tipo==='input'
                                            ? (()=>{
                                                const mascara=String(campo.tipoInput||'').toLowerCase();
                                                const ehMascara=['moeda','cnpj','cep'].includes(mascara);
                                                const valorExibido=ehMascara?aplicarMascaraCampo(v,mascara):v;
                                                return <input id={campo.id} type={ehMascara?'text':campo.tipoInput||'text'} inputMode={ehMascara?'numeric':undefined} value={valorExibido} placeholder={String(v??'').trim()? (campo.placeholder||'') : (campo.placeholder||descricaoCampo(campo))} title={descricaoCampo(campo)||undefined} className={campoValido(campo,v)?'':'campo-invalido'} onChange={e=>{
                                                    if(ehMascara){
                                                        const valorFormatado=aplicarMascaraCampo(e.target.value,mascara);
                                                        const valorBruto=window.DocumentoUtils?.normalizarValorCampo
                                                            ? DocumentoUtils.normalizarValorCampo(valorFormatado,mascara)
                                                            : valorFormatado;
                                                        onChange(campo.id,valorBruto);
                                                    }else{
                                                        onChange(campo.id,e.target.value);
                                                    }
                                                }}/>;
                                            })()
                                            : campo.tipo==='number'
                                                ? (()=>{
                                                    const mascara=String(campo.tipoInput||'').toLowerCase();
                                                    const ehMascara=['moeda','cnpj','cep'].includes(mascara);
                                                    const valorExibido=ehMascara?aplicarMascaraCampo(v,mascara):v;
                                                    return <input id={campo.id} type={ehMascara?'text':'number'} inputMode={ehMascara?'numeric':undefined} value={valorExibido} min={ehMascara?undefined:campo.min} max={ehMascara?undefined:campo.max} step={ehMascara?undefined:campo.step} placeholder={String(v??'').trim()?'':(campo.placeholder||descricaoCampo(campo))} title={descricaoCampo(campo)||undefined} onChange={e=>{
                                                        if(ehMascara){
                                                            const valorFormatado=aplicarMascaraCampo(e.target.value,mascara);
                                                            const valorBruto=window.DocumentoUtils?.normalizarValorCampo
                                                                ? DocumentoUtils.normalizarValorCampo(valorFormatado,mascara)
                                                                : valorFormatado;
                                                            onChange(campo.id,valorBruto);
                                                        }else{
                                                            onChange(campo.id,e.target.value);
                                                        }
                                                    }}/>;
                                                })()
                                                : campo.tipo==='date'
                                                    ? <input id={campo.id} type="date" value={v} title={descricaoCampo(campo)||undefined} onChange={e=>onChange(campo.id,e.target.value)}/>
                                                    : campo.tipo==='textarea'
                                                        ? <textarea id={campo.id} value={v} rows={campo.rows||4} placeholder={String(v??'').trim()?'':descricaoCampo(campo)} title={descricaoCampo(campo)||undefined} onChange={e=>onChange(campo.id,e.target.value)}/>
                                                        : null}
                                     {String(campo.validar||campo.tipoInput||'').toLowerCase()==='email'&&!campoValido(campo,v)&&<span className="campo-erro">E-mail inválido.</span>}
                                     {String(campo.validar||campo.tipoInput||'').toLowerCase()==='cnpj'&&!campoValido(campo,v)&&<span className="campo-erro">CNPJ inválido.</span>}
                                     {String(campo.validar||campo.tipoInput||'').toLowerCase()==='cep'&&!campoValido(campo,v)&&<span className="campo-erro">CEP inválido.</span>}

                                     {String(campo.validar||campo.tipoInput||'').toLowerCase()==='cnpj'&&consultaCNPJ.chave===normalizarDigitos(v)&&consultaCNPJ.carregando&&<span className="campo-info-api">Consultando CNPJ...</span>}
                                     {String(campo.validar||campo.tipoInput||'').toLowerCase()==='cnpj'&&consultaCNPJ.chave===normalizarDigitos(v)&&consultaCNPJ.erro&&<span className="campo-consulta-erro">{consultaCNPJ.erro} <button type="button" className="edm-retry-button" onClick={()=>executarConsultaCNPJ(normalizarDigitos(v))}>Tentar novamente</button></span>}
                                     {String(campo.validar||campo.tipoInput||'').toLowerCase()==='cnpj'&&consultaCNPJ.dados&&consultaCNPJ.chave===normalizarDigitos(v)&&(
                                         <span className="campo-info-api">
                                             <strong>{consultaCNPJ.dados.razao_social||'Razão social não informada'}</strong><br/>
                                             {consultaCNPJ.dados.nome_fantasia||'Nome fantasia não informado'}<br/>
                                             Situação: {consultaCNPJ.dados.situacao_cadastral||'Não informada'}<br/>
                                             {consultaCNPJ.dados.municipio||'Não informado'}{consultaCNPJ.dados.uf?` - ${consultaCNPJ.dados.uf}`:''}<br/>
                                             Capital social: {consultaCNPJ.dados.capital_social||'Não informado'}
                                         </span>
                                     )}

                                     {String(campo.validar||campo.tipoInput||'').toLowerCase()==='cep'&&consultaCEP.chave===normalizarDigitos(v)&&consultaCEP.carregando&&<span className="campo-info-api">Consultando CEP...</span>}
                                     {String(campo.validar||campo.tipoInput||'').toLowerCase()==='cep'&&consultaCEP.chave===normalizarDigitos(v)&&consultaCEP.erro&&<span className="campo-consulta-erro">{consultaCEP.erro} <button type="button" className="edm-retry-button" onClick={()=>executarConsultaCEP(normalizarDigitos(v))}>Tentar novamente</button></span>}
                                     {String(campo.validar||campo.tipoInput||'').toLowerCase()==='cep'&&consultaCEP.dados&&consultaCEP.chave===normalizarDigitos(v)&&(
                                         <span className="campo-info-api">
                                             {[consultaCEP.dados.logradouro,consultaCEP.dados.bairro,consultaCEP.dados.localidade]
                                                 .map(v=>String(v||'').trim())
                                                 .filter(Boolean)
                                                 .join(', ')}
                                             {consultaCEP.dados.uf?` - ${consultaCEP.dados.uf}`:''}
                                         </span>
                                     )}

                                    {campo.tipo==='select'&&(
                                        <select id={campo.id} value={v} title={descricaoCampo(campo)||undefined} onChange={e=>onChange(campo.id,e.target.value)}>
                                            <option value="">Selecione...</option>
                                            {campo.opcoes.map((opcao,i)=><option key={i} value={opcao}>{opcao}</option>)}
                                        </select>
                                    )}

                                    {campo.tipo==='checkbox'&&(
                                        <div className="checkbox-group">
                                            <input id={campo.id} type="checkbox" checked={v===true} title={descricaoCampo(campo)||undefined} onChange={e=>onChange(campo.id,e.target.checked)}/>
                                            <label htmlFor={campo.id} title={descricaoCampo(campo)||undefined} onClick={e=>{e.stopPropagation();setFocoPendente(false);setFocoResto(false);EDM_AOP.interagir(campo.id,'campo');}}>{campo.label}</label>
                                        </div>
                                    )}

                                    {campo.tipo==='radio'&&(
                                        <div className="radio-group" title={descricaoCampo(campo)||undefined}>
                                            {campo.opcoes.map((opcao,i)=>(
                                                <label key={i} htmlFor={`${campo.id}-${i}`} title={descricaoCampo(campo)||undefined}>
                                                    <input id={`${campo.id}-${i}`} type="radio" name={campo.id} value={opcao} checked={v===opcao} title={descricaoCampo(campo)||undefined} onChange={e=>onChange(campo.id,e.target.value)}/>
                                                    {opcao}
                                                </label>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                </section>
            ))}
        </aside>
    );
}

window.EDM_UI_PainelCampos = PainelCampos;
