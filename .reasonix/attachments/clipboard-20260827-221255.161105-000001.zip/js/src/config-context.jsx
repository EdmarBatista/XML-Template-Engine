/* =========================================================
   Contexto de configuração + estado de foco + persistência
   (substitui os antigos window.edm* de estado)
   ========================================================= */

const ConfigContext = React.createContext(null);

function ConfigProvider({ children }){
    const [edicaoInline, setEdicaoInline] = React.useState(()=>{try{const v=window.EDM_Storage.get('edmEdicaoInline');return v===null?true:v==='true';}catch(error){return true;}});
    const [irParaCampo, setIrParaCampo] = React.useState(()=>{try{const v=window.EDM_Storage.get('edmIrParaCampo');return v===null?true:v==='true';}catch(error){return true;}});
    const [deslocarDocumento, setDeslocarDocumento] = React.useState(()=>{try{const v=window.EDM_Storage.get('edmDeslocarDocumento');return v===null?true:v==='true';}catch(error){return true;}});
    const [numeracaoAtiva, setNumeracaoAtiva] = React.useState(()=>{try{const v=window.EDM_Storage.get('edmNumeracaoAtiva');return v===null?true:v==='true';}catch(error){return true;}});
    const [variaveisVermelhasWord, setVariaveisVermelhasWord] = React.useState(()=>{try{const v=window.EDM_Storage.get('edmVariaveisVermelhasWord');return v===null?true:v==='true';}catch(error){return true;}});

    /* Estado de foco (antes em window.edmFocoUsuarioPendente/Restaurado/FocosProgramaticos). */
    const [focoUsuarioPendente, setFocoUsuarioPendente] = React.useState(false);
    const [focoRestaurado, setFocoRestaurado] = React.useState(false);
    const focosProgramaticos = React.useRef(new Set());
    const focoStateRef = React.useRef({ pendente: false, restaurado: false });
    const setFocoPendente = React.useCallback((v) => {
        focoStateRef.current.pendente = v;
        setFocoUsuarioPendente(v);
    }, []);
    const setFocoResto = React.useCallback((v) => {
        focoStateRef.current.restaurado = v;
        setFocoRestaurado(v);
    }, []);

    React.useEffect(()=>{
        const onPointer = ()=>{ setFocoPendente(true); setFocoResto(false); };
        const onKey = ()=>{ setFocoPendente(true); setFocoResto(false); };
        const onBlur = ()=>{ setFocoResto(true); setFocoPendente(false); };
        const onVis = ()=>{ if(document.hidden){ setFocoResto(true); setFocoPendente(false); } };
        window.addEventListener('pointerdown', onPointer, {capture:true});
        window.addEventListener('keydown', onKey, {capture:true});
        window.addEventListener('blur', onBlur);
        document.addEventListener('visibilitychange', onVis, {capture:true});
        return ()=>{
            window.removeEventListener('pointerdown', onPointer, {capture:true});
            window.removeEventListener('keydown', onKey, {capture:true});
            window.removeEventListener('blur', onBlur);
            document.removeEventListener('visibilitychange', onVis, {capture:true});
        };
    }, [setFocoPendente, setFocoResto]);

    React.useEffect(()=>{
        window.EDM_Storage.set('edmEdicaoInline', String(edicaoInline));
        window.EDM_Storage.set('edmIrParaCampo', String(irParaCampo));
        window.EDM_Storage.set('edmDeslocarDocumento', String(deslocarDocumento));
        window.EDM_Storage.set('edmNumeracaoAtiva', String(numeracaoAtiva));
        // Ponte de leitura (híbrida) usada por painel-variaveis.js e renderizador.js não-React.
        window.edmIrParaCampo = irParaCampo;
    },[edicaoInline, irParaCampo, deslocarDocumento, numeracaoAtiva]);

    React.useEffect(()=>{
        window.EDM_Storage.set('edmVariaveisVermelhasWord', String(variaveisVermelhasWord));
    },[variaveisVermelhasWord]);

    const value = React.useMemo(()=>({
        edicaoInline, setEdicaoInline,
        irParaCampo, setIrParaCampo,
        deslocarDocumento, setDeslocarDocumento,
        numeracaoAtiva, setNumeracaoAtiva,
        variaveisVermelhasWord, setVariaveisVermelhasWord,
        focoUsuarioPendente, setFocoPendente,
        focoRestaurado, setFocoResto,
        focosProgramaticos,
        focoStateRef
    }), [edicaoInline, irParaCampo, deslocarDocumento, numeracaoAtiva, variaveisVermelhasWord,
         focoUsuarioPendente, focoRestaurado, setFocoPendente, setFocoResto]);

    return <ConfigContext.Provider value={value}>{children}</ConfigContext.Provider>;
}

function useConfig(){
    const ctx = React.useContext(ConfigContext);
    if(!ctx) throw new Error('useConfig deve ser usado dentro de ConfigProvider');
    return ctx;
}

window.EDM_Config = { ConfigContext, ConfigProvider, useConfig };
