/* =========================================================
   Componentes App e TemplateApp
   ========================================================= */
const { useConfig } = window.EDM_Config;
const { normalizarNomeXml, chaveXml, baixarPreenchimentoJSON } = window.EDM_Utils;
const {
    storage: EDM_STORAGE,
    EDM_LAST_XML_KEY, EDM_DATA_STORAGE_KEY, EDM_SECTIONS_STORAGE_KEY,
    salvarXMLPersistente, obterXMLPersistente, carregarXML,
    carregarDadosSalvos, salvarDados, limparDadosSalvos,
    carregarEstadoSecoes, salvarEstadoSecoes
} = window.EDM_Storage;
const { parseXMLString } = window.EDM_XmlParser;
const { criarModeloIntermediarioCompleto, obterCaminhoCampo, obterTooltipCampo } = window.EDM_Modelo;
const PainelCampos = window.EDM_UI_PainelCampos;
const VisualizadorDocumento = window.EDM_UI_VisualizadorDocumento;

function App(){
    const[xmlInfo,setXmlInfo]=React.useState(null);
    const[error,setError]=React.useState(null);
    const[dadosJson,setDadosJson]=React.useState(null);

    React.useEffect(()=>{
        carregarXML().then(setXmlInfo).catch(err=>setError(err.message));
    },[]);

    const carregarArquivo=React.useCallback(file=>{
        if(!file)return;
        const reader=new FileReader();
        reader.onload=e=>{
            try{
                const xmlString=e.target.result;
                const novoDoc=parseXMLString(xmlString);
                const nome=normalizarNomeXml(file.name);
                salvarXMLPersistente(nome,xmlString);
                try{EDM_STORAGE.set(EDM_LAST_XML_KEY,nome);}catch(error){}
                setDadosJson(null);
                setXmlInfo({doc:novoDoc,nome});
                setError(null);
            }catch(err){
                setError('Erro ao processar: '+err.message);
            }
        };
        reader.readAsText(file);
    },[]);

    const carregarJSON=React.useCallback(file=>{
        if(!file)return;

        const reader=new FileReader();

        reader.onload=e=>{
            try{
                const texto=String(e.target.result||'');
                const json=JSON.parse(texto);

                if(!json||typeof json!=='object'||!json.dados||typeof json.dados!=='object'){
                    throw new Error('JSON de preenchimento inválido. É necessário possuir o objeto "dados".');
                }

                const nomeJson=normalizarNomeXml(json.xml||'exemplo.xml');
                const xmlSalvo=obterXMLPersistente(nomeJson);

                if(xmlSalvo){
                    const doc=parseXMLString(xmlSalvo);
                    try{EDM_STORAGE.set(EDM_LAST_XML_KEY,nomeJson);}catch(error){}
                    setXmlInfo({doc,nome:nomeJson});
                    setDadosJson({...json,xml:nomeJson});
                    setError(null);
                    return;
                }

                if(xmlInfo&&normalizarNomeXml(xmlInfo.nome)===nomeJson){
                    setDadosJson({...json,xml:nomeJson});
                    setError(null);
                    return;
                }

                throw new Error(`O XML "${nomeJson}" correspondente ao preenchimento não está carregado ou salvo neste navegador.`);
            }catch(err){
                setError('Erro ao carregar JSON: '+err.message);
            }
        };

        reader.readAsText(file,'UTF-8');
    },[xmlInfo]);

    window.edmCarregarArquivo=carregarArquivo;
    window.edmCarregarJSON=carregarJSON;

    const handleFileUpload=event=>carregarArquivo(event.target.files?.[0]);
    const handleJsonUpload=event=>carregarJSON(event.target.files?.[0]);

    if(error){
        return(
            <div className="erro-container">
                <h2>Erro</h2>
                <p>{error}</p>
                <div>
                    <input type="file" accept=".xml" onChange={handleFileUpload}/>
                    <input type="file" accept=".json,application/json" onChange={handleJsonUpload}/>
                </div>
            </div>
        );
    }

    if(!xmlInfo)return <div className="carregando">Carregando...</div>;

    return(
        <TemplateApp
            xmlDoc={xmlInfo.doc}
            xmlName={xmlInfo.nome}
            onFileUpload={handleFileUpload}
            dadosJson={dadosJson}
            onJsonUpload={handleJsonUpload}
        />
    );
}

function TemplateApp({xmlDoc,xmlName,onFileUpload,dadosJson,onJsonUpload}){
    const modelo=React.useMemo(()=>{try{return criarModeloIntermediarioCompleto(xmlDoc)}catch(error){return null}},[xmlDoc]);
    const modeloSeguro=modelo||{formulario:{grupos:[],campos:{}},dados:{},conteudo:{filhos:[]}};
    const listaCampos=React.useMemo(()=>{
        const nomes=new Set();
        const percorrer=nodes=>{
            (nodes||[]).forEach(node=>{
                if(node?.tipo==='foreach' && node.atributos?.lista)nomes.add(String(node.atributos.lista));
                percorrer(node?.filhos);
            });
        };
        percorrer(modeloSeguro.conteudo?.filhos);
        return nomes;
    },[modeloSeguro]);
    const[dados,setDados]=React.useState(()=>carregarDadosSalvos(modeloSeguro,xmlName));
    React.useEffect(()=>{
        if(!modelo)return;
        const salvos=carregarDadosSalvos(modeloSeguro,xmlName);
        if(dadosJson?.dados&&normalizarNomeXml(dadosJson.xml||'')===normalizarNomeXml(xmlName)){
            Object.keys(modeloSeguro.dados).forEach(id=>{
                if(Object.prototype.hasOwnProperty.call(dadosJson.dados,id))salvos[id]=dadosJson.dados[id];
            });
        }
        setDados(salvos);
    },[modelo,modeloSeguro,xmlName,dadosJson]);
    const[ultimoCampoAlterado,setUltimoCampoAlterado]=React.useState(null);
    const[origemCampoAlterado,setOrigemCampoAlterado]=React.useState(null);
    const[versaoCampoAlterado,setVersaoCampoAlterado]=React.useState(0);
    const[menuCollapsed,setMenuCollapsed]=React.useState(()=>{try{return EDM_STORAGE.get('edmSidebarCollapsed')==='true';}catch(error){return false;}});
    const sidebarRef=React.useRef(null);
    const resizerRef=React.useRef(null);

    React.useEffect(()=>{
        const sidebar=sidebarRef.current;
        const resizer=resizerRef.current;
        if(!sidebar||!resizer)return;

        const WIDTH_KEY='edmSidebarWidth';
        const DEFAULT_WIDTH=360;
        const MIN_WIDTH=260;
        const MAX_GUTTER=80;
        const BREAKPOINT=900;
        const desktop=()=>window.innerWidth>BREAKPOINT;
        const clamp=w=>Math.max(MIN_WIDTH,Math.min(Number(w)||DEFAULT_WIDTH,window.innerWidth-MAX_GUTTER));
        const getWidth=()=>sidebar.getBoundingClientRect().width;

        const setWidth=(w,save=true)=>{
            if(!desktop())return;
            const value=clamp(w);
            const app=sidebar.closest('.app-container');
            if(app)app.style.setProperty('--edm-sidebar-width',value+'px');
            sidebar.style.width=value+'px';
            sidebar.style.minWidth=value+'px';
            sidebar.style.maxWidth=value+'px';
            sidebar.style.flexBasis=value+'px';
            if(save){try{EDM_STORAGE.set(WIDTH_KEY,String(Math.round(value)));}catch(error){}}
        };

        if(desktop()){
            let saved=DEFAULT_WIDTH;
            try{
                const v=parseFloat(EDM_STORAGE.get(WIDTH_KEY));
                if(Number.isFinite(v))saved=v;
            }catch(error){}
            setWidth(saved,false);
        }

        let moving=false,pid=null,startX=0,startWidth=0;

        const onDown=e=>{
            if(!desktop()||sidebar.closest('.app-container')?.classList.contains('sidebar-collapsed'))return;
            if(e.pointerType==='mouse'&&e.button!==0)return;
            moving=true;
            pid=e.pointerId;
            startX=e.clientX;
            startWidth=getWidth();
            resizer.classList.add('dragging');
            document.body.classList.add('edm-resizing');
            try{resizer.setPointerCapture(pid);}catch(error){}
            e.preventDefault();
        };

        const onMove=e=>{
            if(!moving||e.pointerId!==pid)return;
            setWidth(startWidth+(e.clientX-startX),false);
            e.preventDefault();
        };

        const stop=e=>{
            if(!moving)return;
            if(e&&e.pointerId!==undefined&&pid!==null&&e.pointerId!==pid)return;
            moving=false;
            resizer.classList.remove('dragging');
            document.body.classList.remove('edm-resizing');
            setWidth(getWidth(),true);
            try{
                if(pid!==null&&resizer.hasPointerCapture(pid))resizer.releasePointerCapture(pid);
            }catch(error){}
            pid=null;
        };

        const onDoubleClick=()=>{
            if(desktop()&&!sidebar.closest('.app-container')?.classList.contains('sidebar-collapsed'))setWidth(DEFAULT_WIDTH,true);
        };
        const onResize=()=>{if(desktop())setWidth(getWidth(),false);};

        resizer.addEventListener('pointerdown',onDown,{passive:false});
        resizer.addEventListener('pointermove',onMove,{passive:false});
        resizer.addEventListener('pointerup',stop);
        resizer.addEventListener('pointercancel',stop);
        resizer.addEventListener('lostpointercapture',stop);
        resizer.addEventListener('dblclick',onDoubleClick);
        window.addEventListener('resize',onResize,{passive:true});

        return()=>{
            resizer.removeEventListener('pointerdown',onDown);
            resizer.removeEventListener('pointermove',onMove);
            resizer.removeEventListener('pointerup',stop);
            resizer.removeEventListener('pointercancel',stop);
            resizer.removeEventListener('lostpointercapture',stop);
            resizer.removeEventListener('dblclick',onDoubleClick);
            window.removeEventListener('resize',onResize);
            document.body.classList.remove('edm-resizing');
        };
    },[menuCollapsed]);

    React.useEffect(()=>{if(modelo)salvarDados(modeloSeguro,dados,xmlName);},[modelo,modeloSeguro,dados,xmlName]);

    const handleChange=React.useCallback((id,value,origem)=>{
        setDados(prev=>({...prev,[id]:value}));
        // Toda alteração gera destaque. Somente a edição inline
        // fica impedida de provocar deslocamento automático.
        setUltimoCampoAlterado(id);
        setOrigemCampoAlterado(origem||'painel');
        setVersaoCampoAlterado(v=>v+1);
    },[]);

    React.useEffect(()=>{window.edmAtualizarCampo=handleChange;return()=>{if(window.edmAtualizarCampo===handleChange)delete window.edmAtualizarCampo}},[handleChange]);
    React.useEffect(()=>{window.edmXmlName=xmlName;window.modelo={...modeloSeguro,dados};window.dispatchEvent(new CustomEvent('edm:modelo-atualizado'))},[modeloSeguro,dados,xmlName]);

    if(!modelo)return <div className="erro-container"><h2>Erro</h2><p>Não foi possível criar o modelo intermediário a partir do XML.</p></div>;

    return(
        <div className={`app-container${menuCollapsed?' sidebar-collapsed':''}`}>
            <PainelCampos
                grupos={modeloSeguro.formulario.grupos}
                campos={modeloSeguro.formulario.campos}
                listaCampos={listaCampos}
                xmlName={xmlName}
                dados={dados}
                onChange={handleChange}
                onFileUpload={onFileUpload}
                onJsonUpload={onJsonUpload}
                collapsed={menuCollapsed}
                sidebarRef={sidebarRef}
                onToggleMenu={()=>{setMenuCollapsed(prev=>{const novo=!prev;try{EDM_STORAGE.set('edmSidebarCollapsed',String(novo));}catch(error){}return novo;})}}
                onShowModel={()=>window.dispatchEvent(new CustomEvent('edm:show-model'))}
                onClear={()=>{const vazios={...modeloSeguro.dados};limparDadosSalvos(xmlName);setDados(vazios);setUltimoCampoAlterado(null);}}
            />
            <div className="edm-resizer" id="edm-resizer" ref={resizerRef} title="Arraste para redimensionar" aria-label="Arraste para redimensionar"></div>
            <VisualizadorDocumento conteudo={modeloSeguro.conteudo} dados={dados} campoAlterado={ultimoCampoAlterado} campoAlteradoVersao={versaoCampoAlterado} origemCampoAlterado={origemCampoAlterado} estrutura={modeloSeguro.formulario}/>
        </div>
    );
}

window.EDM_UI_App = { App, TemplateApp };
