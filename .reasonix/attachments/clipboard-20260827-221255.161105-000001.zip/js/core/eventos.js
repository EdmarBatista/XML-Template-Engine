(function(global){
'use strict';

/* =========================================================
   Eventos/AOP do Motor de Templates
   ========================================================= */

const EDM_AOP={
    pontos:new Map(),
    on(ponto,advice){
        if(!this.pontos.has(ponto))this.pontos.set(ponto,new Set());
        const set=this.pontos.get(ponto);set.add(advice);
        return()=>set.delete(advice);
    },
    emit(ponto,contexto={}){
        this.pontos.get(ponto)?.forEach(fn=>{try{fn(contexto)}catch(e){console.error('[EDM AOP]',e);}});
    },
    interagir(id,origem='documento'){if(id)this.emit('interacao',{id,origem});}
};

global.EDM_Eventos = { AOP: EDM_AOP };
})(window);
