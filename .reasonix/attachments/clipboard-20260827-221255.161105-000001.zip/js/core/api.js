(function (global) {
'use strict';

/* =========================================================
   Consultas a APIs externas (opencnpj e viacep)
   com timeout/AbortController, cache em memória e debounce.
   ========================================================= */

const CACHE = new Map();
const TIMEOUT_MS = 8000;

function cacheLer(chave) {
    const entry = CACHE.get(chave);
    if (!entry) return undefined;
    if (entry.expira <= Date.now()) {
        CACHE.delete(chave);
        return undefined;
    }
    return entry.valor;
}

function cacheGravar(chave, valor, ttlMs = 5 * 60 * 1000) {
    CACHE.set(chave, { valor, expira: Date.now() + ttlMs });
}

function consultarComTimeout(url, signal) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), TIMEOUT_MS);
    const onAbort = () => controller.abort();
    if (signal) signal.addEventListener('abort', onAbort, { once: true });

    return fetch(url, { signal: controller.signal })
        .finally(() => {
            clearTimeout(timeout);
            if (signal) signal.removeEventListener('abort', onAbort);
        });
}

// Retorna { cancelar } para permitir cancelar a requisição em andamento.
function consultarCNPJ(cnpj, opcoes = {}) {
    const chave = 'cnpj:' + cnpj;
    const emCache = cacheLer(chave);
    if (emCache !== undefined) {
        return Promise.resolve({ dados: emCache, cacheado: true, cancelar() {} });
    }

    const controller = new AbortController();
    if (opcoes.signal) {
        opcoes.signal.addEventListener('abort', () => controller.abort(), { once: true });
    }

    const promessa = consultarComTimeout('https://api.opencnpj.org/' + cnpj, controller.signal)
        .then(async (resposta) => {
            if (!resposta.ok) throw new Error('HTTP ' + resposta.status);
            return resposta.json();
        })
        .then((dados) => {
            cacheGravar(chave, dados);
            return dados;
        });

    return {
        promessa,
        cancelar: () => controller.abort()
    };
}

function consultarCEP(cep, opcoes = {}) {
    const chave = 'cep:' + cep;
    const emCache = cacheLer(chave);
    if (emCache !== undefined) {
        return Promise.resolve({ dados: emCache, cacheado: true, cancelar() {} });
    }

    const controller = new AbortController();
    if (opcoes.signal) {
        opcoes.signal.addEventListener('abort', () => controller.abort(), { once: true });
    }

    const promessa = consultarComTimeout('https://viacep.com.br/ws/' + cep + '/json/', controller.signal)
        .then(async (resposta) => {
            if (!resposta.ok) throw new Error('HTTP ' + resposta.status);
            return resposta.json();
        })
        .then((dados) => {
            if (dados && dados.erro) throw new Error('CEP não encontrado');
            cacheGravar(chave, dados);
            return dados;
        });

    return {
        promessa,
        cancelar: () => controller.abort()
    };
}

// Debounce genérico: devolve uma função que só executa após a pausa.
function criarDebounce(fn, esperaMs = 400) {
    let timer = null;
    return function (...args) {
        if (timer) clearTimeout(timer);
        timer = setTimeout(() => {
            timer = null;
            fn(...args);
        }, esperaMs);
    };
}

global.EDM_Api = {
    consultarCNPJ,
    consultarCEP,
    criarDebounce,
    cache: CACHE
};
})(window);
