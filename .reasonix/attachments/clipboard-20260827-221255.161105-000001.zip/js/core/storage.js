(function(global){
'use strict';

/* =========================================================
   Persistência (localStorage) do Motor de Templates (EDM)
   ========================================================= */

const EDM_XML_STORAGE_KEY='edmMotorXml';
const EDM_LAST_XML_KEY='edmMotorUltimoXml';
const EDM_DATA_STORAGE_KEY='edmMotorDados';
const EDM_SECTIONS_STORAGE_KEY='edmMotorSecoes';
const EDM_JSON_VERSION=1;

const EDM_STORAGE={get(key){try{return localStorage.getItem(key)}catch(error){return null}},set(key,value){try{localStorage.setItem(key,value);return true}catch(error){console.warn('Não foi possível salvar no armazenamento:',error);return false}},remove(key){try{localStorage.removeItem(key);return true}catch(error){return false}}};

function normalizarNomeXml(nome){
    const base=String(nome||'exemplo.xml').split(/[\\/]/).pop().trim();
    return base||'exemplo.xml';
}
function chaveXml(nome){
    return normalizarNomeXml(nome).toLowerCase();
}
function lerRegistroXml(){
    try{
        const bruto=EDM_STORAGE.get(EDM_XML_STORAGE_KEY);
        if(!bruto)return {};
        const obj=JSON.parse(bruto);
        if(obj&&typeof obj==='object'&&!Array.isArray(obj))return obj;
    }catch(error){}
    // Compatibilidade com a versão anterior, que guardava somente o XML.
    try{
        const legado=EDM_STORAGE.get(EDM_XML_STORAGE_KEY);
        if(legado&&legado.trim().startsWith('<'))return {'exemplo.xml':{nome:'exemplo.xml',xml:legado}};
    }catch(error){}
    return {};
}
function salvarXMLPersistente(nome,xmlString){
    try{
        const registros=lerRegistroXml();
        const nomeReal=normalizarNomeXml(nome);
        registros[chaveXml(nomeReal)]={nome:nomeReal,xml:xmlString};
        EDM_STORAGE.set(EDM_XML_STORAGE_KEY,JSON.stringify(registros));
    }catch(error){console.warn('Não foi possível salvar o XML:',error);}
}
function obterXMLPersistente(nome){
    try{
        const registros=lerRegistroXml();
        return registros[chaveXml(nome)]?.xml||'';
    }catch(error){return '';}
}
async function carregarXML(){
    const nomePadrao='exemplo.xml';
    let ultimoNome='';
    try{ultimoNome=normalizarNomeXml(EDM_STORAGE.get(EDM_LAST_XML_KEY)||'');}catch(error){}

    if(ultimoNome){
        const xmlUltimo=obterXMLPersistente(ultimoNome);
        if(xmlUltimo){
            try{return {doc:window.EDM_XmlParser.parseXMLString(xmlUltimo),nome:ultimoNome};}
            catch(error){console.warn('XML salvo inválido, tentando o XML de exemplo.',error);}
        }
    }

    const xmlSalvo=obterXMLPersistente(nomePadrao);
    if(xmlSalvo){
        try{return {doc:window.EDM_XmlParser.parseXMLString(xmlSalvo),nome:nomePadrao};}
        catch(error){console.warn('XML de exemplo salvo inválido, usando o XML embutido.',error);}
    }

    const xmlFallback=carregarXMLFallback();
    salvarXMLPersistente(nomePadrao,xmlFallback);
    try{EDM_STORAGE.set(EDM_LAST_XML_KEY,nomePadrao);}catch(error){}
    return {doc:window.EDM_XmlParser.parseXMLString(xmlFallback),nome:nomePadrao};
}
function carregarXMLFallback(){
    const xmlElement=document.getElementById('xml-data');
    if(!xmlElement)throw new Error('Template XML não encontrado.');
    const xml=xmlElement.textContent||'';
    if(!xml.trim())throw new Error('Template XML vazio.');
    return xml;
}

function carregarDadosSalvos(modelo,nomeXml){
    const iniciais={...modelo.dados};
    try{
        const bruto=EDM_STORAGE.get(EDM_DATA_STORAGE_KEY);
        if(!bruto)return iniciais;
        const registros=JSON.parse(bruto);
        const temFormatoPorXml=Object.values(registros||{}).some(v=>v&&typeof v==='object'&&Object.prototype.hasOwnProperty.call(v,'dados'));
        const salvos=temFormatoPorXml?(registros?.[chaveXml(nomeXml)]?.dados||{}):registros||{};
        Object.keys(iniciais).forEach(id=>{
            if(Object.prototype.hasOwnProperty.call(salvos,id))iniciais[id]=salvos[id];
        });
    }catch(error){console.warn('Não foi possível restaurar os valores salvos:',error);}
    return iniciais;
}
function salvarDados(modelo,dados,nomeXml){
    try{
        let registros={};
        const bruto=EDM_STORAGE.get(EDM_DATA_STORAGE_KEY);
        if(bruto)try{registros=JSON.parse(bruto)||{};}catch(error){}
        const compat={};
        Object.keys(modelo.dados).forEach(id=>{if(Object.prototype.hasOwnProperty.call(dados,id))compat[id]=dados[id];});
        const key=chaveXml(nomeXml);
        registros[key]={nome:normalizarNomeXml(nomeXml),dados:compat};
        EDM_STORAGE.set(EDM_DATA_STORAGE_KEY,JSON.stringify(registros));
    }catch(error){console.warn('Não foi possível salvar os valores:',error);}
}
function limparDadosSalvos(nomeXml){
    try{
        const bruto=EDM_STORAGE.get(EDM_DATA_STORAGE_KEY);
        const registros=bruto?JSON.parse(bruto)||{}:{};
        delete registros[chaveXml(nomeXml)];
        EDM_STORAGE.set(EDM_DATA_STORAGE_KEY,JSON.stringify(registros));
    }catch(error){}
}
function carregarEstadoSecoes(grupos,nomeXml){
    const padrao={};
    grupos.forEach((_,i)=>padrao[i]=true);
    try{
        const bruto=EDM_STORAGE.get(EDM_SECTIONS_STORAGE_KEY);
        const registros=bruto?JSON.parse(bruto)||{}:{};
        const salvo=registros[chaveXml(nomeXml)]?.abertas;
        if(salvo&&typeof salvo==='object')Object.keys(padrao).forEach(i=>{if(typeof salvo[i]==='boolean')padrao[i]=salvo[i];});
    }catch(error){}
    return padrao;
}
function salvarEstadoSecoes(nomeXml,abertas,selecionada){
    try{
        const bruto=EDM_STORAGE.get(EDM_SECTIONS_STORAGE_KEY);
        const registros=bruto?JSON.parse(bruto)||{}:{};
        registros[chaveXml(nomeXml)]={nome:normalizarNomeXml(nomeXml),abertas,selecionada};
        EDM_STORAGE.set(EDM_SECTIONS_STORAGE_KEY,JSON.stringify(registros));
    }catch(error){}
}

global.EDM_Storage = {
    EDM_XML_STORAGE_KEY,
    EDM_LAST_XML_KEY,
    EDM_DATA_STORAGE_KEY,
    EDM_SECTIONS_STORAGE_KEY,
    EDM_JSON_VERSION,
    storage: EDM_STORAGE,
    lerRegistroXml,
    salvarXMLPersistente,
    obterXMLPersistente,
    carregarXML,
    carregarXMLFallback,
    carregarDadosSalvos,
    salvarDados,
    limparDadosSalvos,
    carregarEstadoSecoes,
    salvarEstadoSecoes,
    get: (k)=>EDM_STORAGE.get(k),
    set: (k,v)=>EDM_STORAGE.set(k,v),
    remove: (k)=>EDM_STORAGE.remove(k)
};
})(window);
