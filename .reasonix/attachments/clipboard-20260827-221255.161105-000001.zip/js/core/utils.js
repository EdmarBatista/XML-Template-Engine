(function(global){
'use strict';

/* =========================================================
   Utilidades gerais do Motor de Templates (EDM)
   ========================================================= */

function normalizarNomeXml(nome){
    const base=String(nome||'exemplo.xml').split(/[\\/]/).pop().trim();
    return base||'exemplo.xml';
}
function chaveXml(nome){
    return normalizarNomeXml(nome).toLowerCase();
}

function esc(v){
    return String(v??'')
        .replace(/&/g,'&amp;')
        .replace(/</g,'&lt;')
        .replace(/>/g,'&gt;')
        .replace(/"/g,'&quot;')
        .replace(/'/g,'&#39;');
}

let __renderKeyCounter=0;
function resetRenderKeys(){__renderKeyCounter=0}
function getNextKey(){return `k${__renderKeyCounter++}`}
function isElementoBloco(tag){
    return ['titulo','subtitulo','lista','tabela','paragrafo','p','if','secao'].includes(tag);
}

function baixarPreenchimentoJSON(xmlName,dados){
    const valores={};
    Object.keys(dados||{}).forEach(id=>{
        valores[id]=dados[id];
    });

    const preenchimento={
        xml:normalizarNomeXml(xmlName),
        dados:valores
    };

    const texto=JSON.stringify(preenchimento,null,2);
    const blob=new Blob([texto],{type:'application/json;charset=utf-8'});
    const url=URL.createObjectURL(blob);
    const a=document.createElement('a');
    const base=normalizarNomeXml(xmlName).replace(/\.xml$/i,'');
    a.href=url;
    a.download=`${base}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
}

/* Toast via Toastify (cdn.jsdelivr.net/npm/toastify-js). */
function toast(mensagem, tipo='info'){
    if(typeof global.Toastify==='function'){
        global.Toastify({
            text: mensagem,
            duration: 3500,
            gravity: 'bottom',
            position: 'right',
            style: {
                background: tipo==='erro'?'#b00020':tipo==='sucesso'?'#1e7d32':'#01579b'
            }
        }).showToast();
    }else{
        // Fallback discreto caso o CDN não esteja disponível.
        if(tipo==='erro')console.error(mensagem);
        else console.info(mensagem);
    }
}

global.EDM_Utils = {
    normalizarNomeXml,
    chaveXml,
    esc,
    baixarPreenchimentoJSON,
    resetRenderKeys,
    getNextKey,
    isElementoBloco,
    toast
};
})(window);
