# XML Template Engine · Editor Interativo

Editor visual de modelos de documentos baseados em XML. A partir de um template XML
(`<formulario>` + `<conteudo>`), renderiza um formulário interativo que preenche um
documento em tempo real e exporta:

- **JSON** de preenchimento (arquivo `.json`);
- **DOCX** (Word), gerado pela biblioteca [docx](https://docx.js.org/).

Não requer servidor: basta abrir o `index.html` (duplo clique) em um navegador moderno.
O React, o docx e o Toastify são carregados por CDN (é necessário estar online).

---

## Como usar

1. Abra `index.html`.
2. Preencha os campos na coluna esquerda. As alterações aparecem no documento à direita.
3. Use os botões da barra superior da coluna para:
   - abrir outro XML (`📂`);
   - carregar um preenchimento JSON;
   - baixar o preenchimento em JSON;
   - **W** — salvar o documento em Word (`.docx`);
   - alternar variáveis vermelhas no Word, edição inline, deslocamento do documento,
     numeração e o painel "Variáveis / Modelo".
4. Também é possível arrastar e soltar um `.xml` ou `.json` sobre a janela.

Os modelos XML e os preenchimentos ficam persistidos no `localStorage` do navegador
(chaves `edmMotorXml`, `edmMotorDados`, `edmMotorSecoes`, etc.).

---

## Schema do template XML

O template tem duas seções principais:

```xml
<documento>
  <formulario> ... </formulario>   <!-- define os campos -->
  <conteudo>  ... </conteudo>      <!-- define o documento -->
</documento>
```

### 1. `<formulario>` (campos)

Campos ficam agrupados dentro de `<grupo titulo="...">`.

| Tag | Atributos | Observações |
|---|---|---|
| `<input>` | `id`, `label`, `descricao`, `exemplo`, `obrigatorio`, `tipo` | `tipo` pode ser `texto`, `email`, `lista_csv`, etc. |
| `<textarea>` | `id`, `label`, `tipo="texto_multilinha"`, `rows` | múltiplas linhas |
| `<number>` | `id`, `label`, `min`, `max`, `step`, `tipo` | `tipo` = `moeda`, `cnpj`, `cep`, `numero_inteiro` |
| `<date>` | `id`, `label`, `tipo="data"` | campo de data |
| `<select>` | `id`, `label`, `tipo="selecao"` | opções em `<option>opção</option>` |
| `<radio>` | `id`, `label`, `tipo="radio"` | idem `<option>` |
| `<checkbox>` | `id`, `label`, `tipo="booleano"` | sem opções |

O atributo `tipo` (ou `validar`/`validacao`) define a máscara e a validação:

- `moeda` → máscara monetária brasileira;
- `cnpj` → máscara + validação de CNPJ + consulta automática (opencnpj);
- `cep` → máscara + validação de CEP + consulta automática (viacep);
- `email` → validação de e-mail;
- `numero_inteiro`, `data`, `selecao`, `radio`, `booleano`.

### 2. `<conteudo>` (documento)

O texto pode conter **variáveis** com filtros opcionais:

```
{{campo}}            → valor bruto
{{campo | filtro}}   → valor formatado
```

Filtros disponíveis (implementados em `funcoes-documento.js` e
`js/avaliador/filtros-mascaras.js`): `moeda`, `data`, `dataExtenso`, `extenso`,
`numero_extenso`, `romano`, `cnpj`, `cep`.

Tags estruturais:

| Tag | Uso |
|---|---|
| `<secao titulo="..." numerar="true|false">` | seção com numeração |
| `<titulo>`, `<subtitulo>` | títulos do documento |
| `<p>`/`<paragrafo>` | parágrafo |
| `<b>`, `<i>`, `<u>` | negrito, itálico, sublinhado |
| `<lista numerada="true|false">` + `<item>` | lista |
| `<tabela>` > `<cabecalho>`/`<linha>` > `<celula>` | tabela |
| `<if expr="...">...</if>` | condicional |
| `<foreach var="x" lista="campoLista">...</foreach>` | repetição |

### Expressões `if`

Operadores: `==`, `!=`, `>`, `<`, `>=`, `<=`, combinados com `&&` e `||`.
Valores literais aceitam aspas simples/duplas, `true`, `false` e números.

```xml
<if expr="valor > 1000 && ativo == 'true'">...</if>
```

### `foreach`

A variável de loop recebe o valor corrente; dentro do bloco, `{{x}}` renderiza o item.
A lista de origem é uma string separada por vírgula ou quebras de linha (ou um campo
do tipo `lista_csv`).

```xml
<foreach var="item" lista="lista">
  <p>- {{item}}</p>
</foreach>
```

---

## Estrutura de arquivos

```
index.html                 página (HTML + ordem de carregamento dos scripts)
css/estilos.css            todo o CSS
funcoes-documento.js       utilidades de domínio (DocumentoUtils)
funcoes-word.js            geração do DOCX (WordEDM)
js/
  core/
    utils.js               EDM_Utils (nomes, esc, download JSON, toast, chaves)
    storage.js             EDM_Storage (persistência em localStorage)
    eventos.js             EDM_Eventos (AOP)
    api.js                 EDM_Api (opencnpj/viacep com timeout/cache/debounce)
  xml/
    parser.js              EDM_XmlParser (XML → campos/variáveis)
    modelo.js              EDM_Modelo (modelo intermediário)
  avaliador/
    expressoes.js          EDM_Expressoes (avaliador de expressões if)
    filtros-mascaras.js    EDM_Validacao (filtros/máscaras/validação)
  ui/
    render/renderizador.js EDM_Render (render do documento em React)
    painel-variaveis.js    painel "Variáveis / Modelo" (não-React)
    drag-drop.js           arrastar e soltar XML/JSON
    compilado/*.js         saída do build Babel (NÃO editar)
  src/                     FONTE dos componentes (.jsx — edite aqui)
    config-context.jsx     ConfigContext/useConfig (config + foco)
    realce.jsx             VariavelInterativa/textoComDestaque
    PainelCampos.jsx       sidebar de campos
    VisualizadorDocumento.jsx
    App.jsx                App + TemplateApp
    main.jsx               bootstrap (monta o React)
scripts/wrap-compiled.js   embrulha os compilados em IIFE
backup/                    cópia dos 3 arquivos originais
```

Cada módulo expõe um namespace em `window` (ex.: `window.EDM_Utils`) e consome as
dependências **na ordem de carregamento** definida no `index.html`.

---

## Desenvolvimento (editar os componentes)

Os componentes React ficam em `js/src/*.jsx`. Após editá-los, recompile:

```bash
npm install        # apenas na primeira vez
npm run build:jsx  # babel js/src → js/ui/compilado + wrap em IIFE
```

O comando compila o JSX para JavaScript clássico (`React.createElement`, sem JSX)
e embrulha cada arquivo em uma IIFE, permitindo abrir o `index.html` via `file://`
sem servidor e sem Babel em runtime.

> Alternativa futura (não implementada): reorganizar em ES modules e empacotar com
> Vite + `vite-plugin-singlefile` para gerar um único `dist/index.html` autocontido
> e offline.

---

## Backup

Antes da refatoração, os arquivos originais foram preservados em `backup/`:
`index.html`, `funcoes-documento.js` e `funcoes-word.js`.
