(function(global) {
'use strict';

const WORD_PADROES = {
    fonte: 'Arial',
    tamanhoFonte: 10,
    corTexto: '000000',
    corVariavel: 'FF0000',
    variaveisVermelhas: false,
    alinhamento: 'justificado',
    recuoPrimeiraLinha: 1.25,
    recuoEsquerdo: 0,
    espacoAntes: 0,
    espacoDepois: 5,
    entreLinhas: 1.15,
    pagina: 'A4',
    margemSuperior: 2,
    margemInferior: 2,
    margemEsquerda: 2,
    margemDireita: 2,
    ativarNumeracaoDocumento: false,
    nivelMaximoNumeracao: 9,
    tituloTamanhoFonte: 14,
    tituloNegrito: true,
    tituloSublinhado: false,
    secaoTamanhoFonte: 12,
    secaoNegrito: true,
    secaoSublinhado: false,
    cabecalhoDistancia: 0.8,
    rodapeDistancia: 0.5,
    recuoLista: 1.9
};

function mesclarOpcoes(opcoes) {
    return { ...WORD_PADROES, ...(opcoes || {}) };
}

function cmParaTwip(cm) {
    const n = Number(cm);
    return Number.isFinite(n) && n >= 0 ? Math.round(n * 567) : 0;
}

function ptParaHalfPoint(pt) {
    const n = Number(pt);
    return Number.isFinite(n) && n > 0 ? Math.round(n * 2) : 20;
}

function garantirDocx() {
    if (!global.docx) throw new Error('A biblioteca docx.js não foi carregada.');
}

function paraHexCor(valor, padrao = '000000') {
    const texto = String(valor || '').replace('#', '').trim();
    return /^[0-9a-fA-F]{6}$/.test(texto) ? texto.toUpperCase() : padrao;
}

function limparTextoXML(valor) {
    return String(valor ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '');
}

function obterValor(json, nome, contexto) {
    if (contexto && Object.prototype.hasOwnProperty.call(contexto, nome)) return contexto[nome];
    if (json?.dados && Object.prototype.hasOwnProperty.call(json.dados, nome)) return json.dados[nome];
    return '';
}

function aplicarFiltro(valor, filtro) {
    const nome = String(filtro || '').trim();

    if (!nome) return valor ?? '';

    if (global.DocumentoUtils && typeof global.DocumentoUtils.aplicarFiltroDocumento === 'function') {
        try {
            return global.DocumentoUtils.aplicarFiltroDocumento(valor, nome);
        } catch (erro) {
            console.warn('Erro ao aplicar filtro:', nome, erro);
        }
    }

    switch (nome.toLowerCase()) {
        case 'moeda':
            return typeof global.formatarMoeda === 'function' ? global.formatarMoeda(valor) : valor;

        case 'cnpj':
            return typeof global.formatarCNPJ === 'function' ? global.formatarCNPJ(valor) : valor;

        case 'cep':
            return typeof global.formatarCEP === 'function' ? global.formatarCEP(valor) : valor;

        default:
            return valor ?? '';
    }
}


/* ================================================================
   PLACEHOLDERS
   ================================================================ */

function valorVariavelVazio(valor) {
    return valor === null || valor === undefined || valor === '';
}

function criarPlaceholder(nome, filtro) {
    return '{{' +
        String(nome).trim() +
        (filtro ? ' | ' + String(filtro).trim() : '') +
        '}}';
}


/* ================================================================
   TEXTO / VARIÁVEIS
   ================================================================ */

function resolverTexto(texto, json, contexto) {
    return limparTextoXML(String(texto ?? '')).replace(
        /\{\{\s*([^}|]+?)\s*(?:\|\s*([^}]+?)\s*)?\}\}/g,
        function(_, nome, filtro) {
            const valorOriginal = obterValor(
                json,
                String(nome).trim(),
                contexto
            );

            if (valorVariavelVazio(valorOriginal)) {
                return criarPlaceholder(nome, filtro);
            }

            let valor = valorOriginal;

            if (filtro) {
                valor = aplicarFiltro(valor, filtro);
            }

            return limparTextoXML(
                valor == null
                    ? criarPlaceholder(nome, filtro)
                    : valor
            );
        }
    );
}

function precisaEspaco(anterior, atual) {
    const a = String(anterior || '');
    const b = String(atual || '');

    if (!a || !b || /\s$/.test(a) || /^\s/.test(b)) return false;
    if (/^[,.;!?%)\]}]/.test(b) || /[(\[{]$/.test(a)) return false;

    return /[\p{L}\p{N}:]$/u.test(a) &&
           /^[\p{L}\p{N}]/u.test(b);
}


/* ================================================================
   SEGMENTOS
   ================================================================ */

function extrairSegmentosTexto(
    texto,
    estilo,
    json,
    contexto,
    opcoes
) {
    const segmentos = [];
    const valor = limparTextoXML(texto);

    const regex =
        /\{\{\s*([^}|]+?)\s*(?:\|\s*([^}]+?)\s*)?\}\}/g;

    let ultimo = 0;
    let match;

    while ((match = regex.exec(valor)) !== null) {

        const antes =
            valor.slice(
                ultimo,
                match.index
            );

        if (antes) {
            segmentos.push({
                texto:
                    resolverTexto(
                        antes,
                        json,
                        contexto
                    ),
                estilo: {
                    ...estilo,
                    cor:
                        estilo.cor ||
                        opcoes.corTexto
                }
            });
        }

        const nome =
            String(match[1]).trim();

        const filtro =
            match[2];

        const valorOriginal =
            obterValor(
                json,
                nome,
                contexto
            );

        let textoVariavel;

        if (
            valorVariavelVazio(
                valorOriginal
            )
        ) {

            /*
             * Variável vazia:
             * preserva o placeholder.
             */
            textoVariavel =
                criarPlaceholder(
                    nome,
                    filtro
                );

        } else {

            let valorVariavel =
                valorOriginal;

            if (filtro) {
                valorVariavel =
                    aplicarFiltro(
                        valorVariavel,
                        filtro
                    );
            }

            textoVariavel =
                limparTextoXML(
                    valorVariavel == null
                        ? criarPlaceholder(
                            nome,
                            filtro
                        )
                        : valorVariavel
                );
        }

        segmentos.push({

            texto:
                textoVariavel,

            estilo: {

                ...estilo,

                /*
                 * A formatação do elemento pai
                 * é preservada.
                 *
                 * Exemplo:
                 *
                 * <b>{{texto}}</b>
                 * <i>{{texto}}</i>
                 * <u>{{texto}}</u>
                 */
                cor:
                    opcoes.variaveisVermelhas
                        ? opcoes.corVariavel
                        : (
                            estilo.cor ||
                            opcoes.corTexto
                        )
            }
        });

        ultimo =
            regex.lastIndex;
    }

    const resto =
        valor.slice(
            ultimo
        );

    if (resto) {

        segmentos.push({

            texto:
                resolverTexto(
                    resto,
                    json,
                    contexto
                ),

            estilo: {

                ...estilo,

                cor:
                    estilo.cor ||
                    opcoes.corTexto
            }
        });
    }

    return segmentos;
}


function criarSegmentosInline(
    node,
    estilo,
    json,
    contexto,
    opcoes
) {

    if (!node) return [];

    if (node.tipo === 'texto') {
        return extrairSegmentosTexto(
            node.texto || '',
            estilo,
            json,
            contexto,
            opcoes
        );
    }

    if (node.tipo === 'b') {
        return criarSegmentosFilhos(
            node.filhos || [],
            {
                ...estilo,
                bold: true
            },
            json,
            contexto,
            opcoes
        );
    }

    if (node.tipo === 'i') {
        return criarSegmentosFilhos(
            node.filhos || [],
            {
                ...estilo,
                italic: true
            },
            json,
            contexto,
            opcoes
        );
    }

    if (node.tipo === 'u') {
        return criarSegmentosFilhos(
            node.filhos || [],
            {
                ...estilo,
                underline: true
            },
            json,
            contexto,
            opcoes
        );
    }

    if (node.tipo === 'br') {
        return [
            {
                texto: '\n',
                estilo
            }
        ];
    }

    return [];
}


function criarSegmentosFilhos(
    filhos,
    estilo,
    json,
    contexto,
    opcoes
) {
    const resultado = [];

    (filhos || []).forEach(
        node =>
            resultado.push(
                ...criarSegmentosInline(
                    node,
                    estilo,
                    json,
                    contexto,
                    opcoes
                )
            )
    );

    return resultado;
}


function normalizarSegmentos(
    segmentos
) {
    const resultado = [];
    let ultimoTexto = '';

    (segmentos || []).forEach(
        segmento => {

            if (
                !segmento ||
                segmento.texto == null
            ) {
                return;
            }

            let texto =
                limparTextoXML(
                    segmento.texto
                );

            if (
                !texto ||
                texto === 'undefined' ||
                texto === 'null'
            ) {
                return;
            }

            if (
                precisaEspaco(
                    ultimoTexto,
                    texto
                )
            ) {
                texto =
                    ' ' + texto;
            }

            resultado.push({
                ...segmento,
                texto
            });

            ultimoTexto =
                texto;
        }
    );

    return resultado;
}


function segmentosParaRuns(
    segmentos,
    opcoes
) {
    return (segmentos || []).map(
        segmento => {

            const estilo =
                segmento.estilo || {};

            return new global.docx.TextRun({

                text:
                    limparTextoXML(
                        segmento.texto
                    ),

                font:
                    estilo.fonte ||
                    opcoes.fonte,

                size:
                    ptParaHalfPoint(
                        estilo.tamanhoFonte ??
                        opcoes.tamanhoFonte
                    ),

                color:
                    paraHexCor(
                        estilo.cor ||
                        opcoes.corTexto
                    ),

                bold:
                    Boolean(
                        estilo.bold
                    ),

                italics:
                    Boolean(
                        estilo.italic
                    ),

                underline:
                    estilo.underline
                        ? {}
                        : undefined
            });
        }
    );
}


/* ================================================================
   PARÁGRAFOS
   ================================================================ */

function espacoParagrafo(
    opcoes
) {
    return {

        before:
            Math.max(
                0,
                Math.round(
                    Number(
                        opcoes.espacoAntes ||
                        0
                    ) * 20
                )
            ),

        after:
            Math.max(
                0,
                Math.round(
                    Number(
                        opcoes.espacoDepois ||
                        0
                    ) * 20
                )
            ),

        line:
            Math.max(
                1,
                Math.round(
                    Number(
                        opcoes.entreLinhas ||
                        1.15
                    ) * 240
                )
            )
    };
}


function alinhamentoWord(
    valor
) {
    const nome =
        String(
            valor || ''
        ).toLowerCase();

    if (
        nome === 'centro' ||
        nome === 'center' ||
        nome === 'centralizado'
    ) {
        return global.docx.AlignmentType.CENTER;
    }

    if (
        nome === 'direita' ||
        nome === 'right'
    ) {
        return global.docx.AlignmentType.RIGHT;
    }

    if (
        nome === 'esquerda' ||
        nome === 'left'
    ) {
        return global.docx.AlignmentType.LEFT;
    }

    return global.docx.AlignmentType.JUSTIFIED;
}


function criarParagrafo(
    runs,
    opcoes,
    ajustes = {}
) {
    const cfg = {
        ...opcoes,
        ...ajustes
    };

    const propriedades = {

        alignment:
            alinhamentoWord(
                cfg.alinhamento
            ),

        indent: {

            firstLine:
                0,

            left:
                Math.max(
                    0,
                    cmParaTwip(
                        cfg.recuoEsquerdo ||
                        0
                    )
                )
        },

        spacing:
            espacoParagrafo(
                cfg
            )
    };

    if (
        cfg.numbering
    ) {
        propriedades.numbering =
            cfg.numbering;
    }

    /*
     * Usado somente nos títulos
     * das seções.
     */
    if (
        cfg.run
    ) {
        propriedades.run =
            cfg.run;
    }

    return new global.docx.Paragraph({

        ...propriedades,

        children:
            runs?.length
                ? runs
                : [
                    new global.docx.TextRun({

                        text:
                            '\u200B',

                        font:
                            cfg.fonte,

                        size:
                            ptParaHalfPoint(
                                cfg.tamanhoFonte
                            ),

                        color:
                            paraHexCor(
                                cfg.corTexto
                            )
                    })
                ]
    });
}


/* ================================================================
   TEXTO → PARÁGRAFOS
   ================================================================ */

function converterTextoEmParagrafos(
    nodes,
    json,
    contexto,
    opcoes,
    nivelSecao,
    numbering,
    recuoSecao
) {

    const resultado = [];

    let atual = [];


    function finalizar() {

        if (
            !atual.length
        ) {
            return;
        }

        const segmentos = [];

        atual.forEach(
            item =>
                segmentos.push(
                    ...criarSegmentosInline(
                        item.node,
                        item.estilo || {},
                        json,
                        contexto,
                        opcoes
                    )
                )
        );

        const normalizados =
            normalizarSegmentos(
                segmentos
            );

        if (
            !normalizados.length
        ) {
            atual = [];
            return;
        }

        const ajustes = {

            recuoPrimeiraLinha:
                0,

            recuoEsquerdo:
                recuoSecao || 0
        };


        if (
            opcoes.ativarNumeracaoDocumento &&
            numbering &&
            Number(nivelSecao) > 0
        ) {

            ajustes.numbering = {

                reference:
                    numbering.reference,

                level:
                    Math.min(
                        Math.max(
                            Number(nivelSecao),
                            0
                        ),
                        opcoes.nivelMaximoNumeracao - 1
                    )
            };
        }


        resultado.push(

            criarParagrafo(
                segmentosParaRuns(
                    normalizados,
                    opcoes
                ),
                opcoes,
                ajustes
            )
        );


        atual = [];
    }


    function adicionarTexto(
        texto,
        estilo
    ) {

        const partes =
            limparTextoXML(
                texto
            )
            .replace(
                /\r\n?/g,
                '\n'
            )
            .split(
                '\n'
            );


        partes.forEach(
            (
                parte,
                indice
            ) => {

                if (
                    indice > 0
                ) {
                    finalizar();
                }

                const limpo =
                    parte.replace(
                        /^[ \t]+/,
                        ''
                    );

                if (
                    !limpo.trim()
                ) {
                    return;
                }

                atual.push({

                    node: {

                        tipo:
                            'texto',

                        texto:
                            limpo
                    },

                    estilo
                });
            }
        );
    }


    function percorrer(
        node,
        estilo
    ) {

        if (!node) return;

        if (
            node.tipo === 'texto'
        ) {

            adicionarTexto(
                node.texto || '',
                estilo
            );

            return;
        }

        if (
            node.tipo === 'b'
        ) {

            (node.filhos || [])
                .forEach(
                    filho =>
                        percorrer(
                            filho,
                            {
                                ...estilo,
                                bold:
                                    true
                            }
                        )
                );

            return;
        }

        if (
            node.tipo === 'i'
        ) {

            (node.filhos || [])
                .forEach(
                    filho =>
                        percorrer(
                            filho,
                            {
                                ...estilo,
                                italic:
                                    true
                            }
                        )
                );

            return;
        }

        if (
            node.tipo === 'u'
        ) {

            (node.filhos || [])
                .forEach(
                    filho =>
                        percorrer(
                            filho,
                            {
                                ...estilo,
                                underline:
                                    true
                            }
                        )
                );

            return;
        }

        if (
            node.tipo === 'br'
        ) {
            finalizar();
        }
    }


    (nodes || []).forEach(
        node =>
            percorrer(
                node,
                {}
            )
    );

    finalizar();

    return resultado;
}


/* ================================================================
   LISTAS
   ================================================================ */

function valoresDaLista(
    valor
) {

    if (
        Array.isArray(
            valor
        )
    ) {

        return valor
            .map(
                item =>
                    String(
                        item
                    ).trim()
            )
            .filter(
                Boolean
            );
    }

    const texto =
        String(
            valor ?? ''
        );

    if (
        !texto.trim()
    ) {
        return [];
    }

    return texto
        .split(
            /,\s*|\r?\n/
        )
        .map(
            item =>
                item.trim()
        )
        .filter(
            Boolean
        );
}


function criarReferenciaLista(
    numero
) {
    return `edmlista${numero}`;
}


function converterItemLista(
    node,
    json,
    contexto,
    opcoes,
    numerada,
    referencia
) {

    const segmentos =
        criarSegmentosFilhos(
            node.filhos || [],
            {},
            json,
            contexto,
            opcoes
        );

    const runs =
        segmentosParaRuns(
            normalizarSegmentos(
                segmentos
            ),
            opcoes
        );

    const configuracao = {

        alignment:
            global.docx.AlignmentType.LEFT,

        indent: {

            firstLine:
                0,

            left:
                Math.max(
                    0,
                    cmParaTwip(
                        opcoes.recuoLista
                    )
                )
        },

        spacing: {

            before:
                0,

            after:
                80
        },

        children:
            runs.length
                ? runs
                : [
                    new global.docx.TextRun({

                        text:
                            '\u200B',

                        font:
                            opcoes.fonte,

                        size:
                            ptParaHalfPoint(
                                opcoes.tamanhoFonte
                            )
                    })
                ]
    };

    if (
        numerada
    ) {

        configuracao.numbering = {

            reference:
                referencia,

            level:
                0
        };
    }

    return new global.docx.Paragraph(
        configuracao
    );
}


function converterLista(
    node,
    json,
    contexto,
    opcoes,
    estado
) {

    const resultado = [];

    const numerada =
        String(
            node.atributos?.numerada ||
            ''
        ).toLowerCase() ===
        'true';

    let referencia =
        null;


    if (
        numerada
    ) {

        estado.contadorListas++;

        referencia =
            criarReferenciaLista(
                estado.contadorListas
            );
    }


    function processar(
        filho,
        contextoAtual
    ) {

        if (!filho) return;

        if (
            filho.tipo === 'item'
        ) {

            resultado.push(
                converterItemLista(
                    filho,
                    json,
                    contextoAtual,
                    opcoes,
                    numerada,
                    referencia
                )
            );

            return;
        }

        if (
            filho.tipo === 'foreach'
        ) {

            const varName =
                filho.atributos?.var;

            const listaNome =
                filho.atributos?.lista;

            if (
                !varName ||
                !listaNome
            ) {
                return;
            }

            const valores =
                valoresDaLista(
                    obterValor(
                        json,
                        listaNome,
                        contextoAtual
                    )
                );

            valores.forEach(
                valor => {

                    const novoContexto = {

                        ...contextoAtual,

                        [varName]:
                            valor
                    };

                    (filho.filhos || [])
                        .forEach(
                            sub =>
                                processar(
                                    sub,
                                    novoContexto
                                )
                        );
                }
            );

            return;
        }

        if (
            filho.tipo === 'if' &&
            avaliarExpressao(
                filho.atributos?.expr,
                json,
                contextoAtual
            )
        ) {

            (filho.filhos || [])
                .forEach(
                    sub =>
                        processar(
                            sub,
                            contextoAtual
                        )
                );
        }
    }


    (node.filhos || [])
        .forEach(
            filho =>
                processar(
                    filho,
                    contexto
                )
        );

    return resultado;
}


/* ================================================================
   EXPRESSÕES
   ================================================================ */

function avaliarExpressao(
    expr,
    json,
    contexto
) {

    if (!expr) return false;

    const dados = {

        ...(json?.dados || {}),

        ...(contexto || {})
    };

    let expressao =
        String(
            expr
        )
        .replace(
            /&gt;/g,
            '>'
        )
        .replace(
            /&lt;/g,
            '<'
        )
        .replace(
            /&amp;/g,
            '&'
        )
        .replace(
            /&quot;/g,
            '"'
        )
        .replace(
            /&apos;/g,
            "'"
        )
        .replace(
            /\bAND\b/gi,
            '&&'
        )
        .replace(
            /\bOR\b/gi,
            '||'
        );

    let resultado =
        '';

    let aspas =
        null;

    let escapado =
        false;

    let i =
        0;


    while (
        i < expressao.length
    ) {

        const caractere =
            expressao[i];

        if (
            escapado
        ) {

            resultado +=
                caractere;

            escapado =
                false;

            i++;

            continue;
        }

        if (
            caractere === '\\' &&
            aspas !== null
        ) {

            resultado +=
                caractere;

            escapado =
                true;

            i++;

            continue;
        }

        if (
            caractere === '"' ||
            caractere === "'"
        ) {

            if (
                aspas === null
            ) {

                aspas =
                    caractere;

            } else if (
                aspas === caractere
            ) {

                aspas =
                    null;
            }

            resultado +=
                caractere;

            i++;

            continue;
        }

        if (
            aspas === null &&
            /[A-Za-z_]/.test(
                caractere
            )
        ) {

            let fim =
                i + 1;

            while (
                fim < expressao.length &&
                /[A-Za-z0-9_]/.test(
                    expressao[fim]
                )
            ) {
                fim++;
            }

            const nome =
                expressao.slice(
                    i,
                    fim
                );

            if (
                nome === 'true' ||
                nome === 'false' ||
                nome === 'null' ||
                nome === 'undefined'
            ) {

                resultado +=
                    nome;

            } else {

                resultado +=
                    JSON.stringify(
                        dados[nome] ??
                        ''
                    );
            }

            i =
                fim;

            continue;
        }

        resultado +=
            caractere;

        i++;
    }

    try {

        return Boolean(
            Function(
                '"use strict"; return (' +
                resultado +
                ');'
            )()
        );

    } catch (erro) {

        console.warn(
            'Não foi possível avaliar expressão:',
            expr,
            '→',
            resultado,
            erro
        );

        return false;
    }
}


/* ================================================================
   IF
   ================================================================ */

function converterIfBloco(
    node,
    json,
    contexto,
    opcoes,
    nivelSecao,
    numbering,
    estado,
    recuoSecao
) {

    if (
        !avaliarExpressao(
            node.atributos?.expr,
            json,
            contexto
        )
    ) {
        return [];
    }

    /*
     * O IF só fica vermelho se a opção estiver ativa.
     */
    const opcoesIf =
        opcoes.variaveisVermelhas

            ? {

                ...opcoes,

                corTexto:
                    opcoes.corVariavel ||
                    'FF0000',

                corVariavel:
                    opcoes.corVariavel ||
                    'FF0000'
            }

            : {

                ...opcoes,

                corTexto:
                    opcoes.corTexto ||
                    '000000'
            };

    return converterBloco(
        node.filhos || [],
        json,
        contexto,
        opcoesIf,
        nivelSecao,
        numbering,
        estado,
        recuoSecao
    );
}


/* ================================================================
   FOREACH
   ================================================================ */

function converterForeachBloco(
    node,
    json,
    contexto,
    opcoes,
    nivelSecao,
    numbering,
    estado,
    recuoSecao
) {

    const resultado = [];

    const varName =
        node.atributos?.var;

    const listaNome =
        node.atributos?.lista;

    if (
        !varName ||
        !listaNome
    ) {
        return resultado;
    }

    const valores =
        valoresDaLista(
            obterValor(
                json,
                listaNome,
                contexto
            )
        );

    valores.forEach(
        valor => {

            resultado.push(

                ...converterBloco(
                    node.filhos || [],
                    json,
                    {
                        ...contexto,
                        [varName]:
                            valor
                    },
                    opcoes,
                    nivelSecao,
                    numbering,
                    estado,
                    recuoSecao
                )
            );
        }
    );

    return resultado;
}


/* ================================================================
   TÍTULOS
   ================================================================ */

function criarTitulo(
    texto,
    json,
    contexto,
    opcoes
) {

    /*
     * Títulos simples também ficam pretos.
     */
    const opcoesTitulo = {

        ...opcoes,

        corTexto:
            '000000',

        corVariavel:
            '000000',

        variaveisVermelhas:
            false
    };

    const segmentos =
        extrairSegmentosTexto(
            texto,
            {
                bold:
                    opcoes.tituloNegrito,

                underline:
                    opcoes.tituloSublinhado,

                tamanhoFonte:
                    opcoes.tituloTamanhoFonte,

                cor:
                    '000000'
            },
            json,
            contexto,
            opcoesTitulo
        );

    return criarParagrafo(
        segmentosParaRuns(
            normalizarSegmentos(
                segmentos
            ),
            opcoesTitulo
        ),
        opcoesTitulo,
        {
            alinhamento:
                'esquerda',

            recuoPrimeiraLinha:
                0,

            recuoEsquerdo:
                0,

            espacoAntes:
                0,

            espacoDepois:
                10
        }
    );
}


/* ================================================================
   TÍTULO DA SEÇÃO
   ================================================================ */

function criarTituloSecao(texto, nivel, json, contexto, opcoes, numbering) {

    /*
     * O título da seção é sempre preto.
     */
    const opcoesTitulo = {
        ...opcoes,
        corTexto: '000000',
        corVariavel: '000000',
        variaveisVermelhas: false
    };

    const segmentos = extrairSegmentosTexto(
        texto,
        {
            bold: opcoes.secaoNegrito,
            underline: opcoes.secaoSublinhado,
            tamanhoFonte: opcoes.secaoTamanhoFonte,
            cor: '000000'
        },
        json,
        contexto,
        opcoesTitulo
    );

    const propriedades = {
        alignment: global.docx.AlignmentType.LEFT,
        indent: { firstLine: 0, left: 0 },
        spacing: {
            before: nivel === 0 ? 240 : 120,
            after: 100
        },

        /*
         * Somente o parágrafo do título
         * recebe a propriedade run.bold.
         *
         * Assim os números dos parágrafos
         * normais continuam sem negrito.
         */
        run: {
            bold: Boolean(opcoes.secaoNegrito),
            font: opcoes.fonte,
            size: ptParaHalfPoint(opcoes.secaoTamanhoFonte),
            color: paraHexCor(opcoesTitulo.corTexto, '000000')
        },

        children: segmentosParaRuns(
            normalizarSegmentos(segmentos),
            opcoesTitulo
        )
    };

    if (opcoes.ativarNumeracaoDocumento && numbering) {
        propriedades.numbering = {
            reference: numbering.reference,
            level: Math.min(
                Math.max(nivel, 0),
                opcoes.nivelMaximoNumeracao - 1
            )
        };
    }

    return new global.docx.Paragraph(propriedades);
}

/* ================================================================
   TABELA
   ================================================================ */

function converterTabela(
    node,
    json,
    contexto,
    opcoes
) {

    const rows = [];

    (node.filhos || [])
        .forEach(
            linha => {

                if (
                    !linha ||
                    ![
                        'cabecalho',
                        'linha'
                    ].includes(
                        linha.tipo
                    )
                ) {
                    return;
                }

                const cells = [];

                (linha.filhos || [])
                    .forEach(
                        celula => {

                            if (
                                !celula ||
                                celula.tipo !==
                                    'celula'
                            ) {
                                return;
                            }

                            const segmentos =
                                criarSegmentosFilhos(
                                    celula.filhos || [],
                                    {},
                                    json,
                                    contexto,
                                    opcoes
                                );

                            const runs =
                                segmentosParaRuns(
                                    normalizarSegmentos(
                                        segmentos
                                    ),
                                    opcoes
                                );

                            cells.push(
                                new global.docx.TableCell({
                                    children: [
                                        criarParagrafo(
                                            runs,
                                            opcoes,
                                            {
                                                alinhamento:
                                                    'esquerda',

                                                recuoPrimeiraLinha:
                                                    0,

                                                recuoEsquerdo:
                                                    0,

                                                espacoAntes:
                                                    0,

                                                espacoDepois:
                                                    0
                                            }
                                        )
                                    ]
                                })
                            );
                        }
                    );

                if (cells.length) {

                    rows.push(
                        new global.docx.TableRow({
                            children:
                                cells
                        })
                    );
                }
            }
        );

    return new global.docx.Table({

        width: {

            size:
                100,

            type:
                global.docx.WidthType.PERCENTAGE
        },

        rows
    });
}


/* ================================================================
   SEÇÃO
   ================================================================ */

function converterSecao(
    node,
    json,
    contexto,
    opcoes,
    nivelSecao,
    numbering,
    estado
) {

    const resultado = [];

    const titulo =
        String(
            node.atributos?.titulo ||
            ''
        ).trim();

    /*
     * numerar="false":
     *
     * - não numera a própria seção;
     * - não numera os filhos;
     * - não consome número.
     */
    const numerarSecao =
        node.atributos?.numerar !==
        'false';

    if (titulo) {

        resultado.push(

            criarTituloSecao(
                titulo,
                nivelSecao,
                json,
                contexto,
                opcoes,
                numerarSecao
                    ? numbering
                    : null
            )
        );
    }

    const numerarFilhos =
        numerarSecao;

    const proximoNivel =
        numerarFilhos
            ? nivelSecao + 1
            : nivelSecao;

    const recuoConteudo =
        proximoNivel <= 1
            ? 0
            : (
                proximoNivel - 1
            ) * 0.5;

    resultado.push(

        ...converterBloco(
            node.filhos || [],
            json,
            contexto,
            opcoes,
            proximoNivel,
            numerarFilhos
                ? numbering
                : null,
            estado,
            recuoConteudo
        )
    );

    return resultado;
}


/* ================================================================
   BLOCO
   ================================================================ */

function converterBloco(
    nodes,
    json,
    contexto,
    opcoes,
    nivelSecao,
    numbering,
    estado,
    recuoSecao = null
) {

    const resultado = [];

    let inlineNodes = [];


    function flushInline() {

        if (
            !inlineNodes.length
        ) {
            return;
        }

        resultado.push(

            ...converterTextoEmParagrafos(
                inlineNodes,
                json,
                contexto,
                opcoes,
                nivelSecao || 0,
                numbering,
                recuoSecao
            )
        );

        inlineNodes = [];
    }


    (nodes || []).forEach(
        node => {

            if (!node) {
                return;
            }

            switch (
                node.tipo
            ) {

                case 'texto':
                case 'b':
                case 'i':
                case 'u':

                    inlineNodes.push(
                        node
                    );

                    break;


                case 'titulo':

                    flushInline();

                    resultado.push(

                        criarTitulo(
                            (node.filhos || [])
                                .map(
                                    item =>
                                        item.texto || ''
                                )
                                .join(''),
                            json,
                            contexto,
                            opcoes
                        )
                    );

                    break;


                case 'secao':

                    flushInline();

                    resultado.push(

                        ...converterSecao(
                            node,
                            json,
                            contexto,
                            opcoes,
                            nivelSecao || 0,
                            numbering,
                            estado
                        )
                    );

                    break;


                case 'if':

                    flushInline();

                    resultado.push(

                        ...converterIfBloco(
                            node,
                            json,
                            contexto,
                            opcoes,
                            nivelSecao || 0,
                            numbering,
                            estado,
                            recuoSecao
                        )
                    );

                    break;


                case 'foreach':

                    flushInline();

                    resultado.push(

                        ...converterForeachBloco(
                            node,
                            json,
                            contexto,
                            opcoes,
                            nivelSecao || 0,
                            numbering,
                            estado,
                            recuoSecao
                        )
                    );

                    break;


                case 'lista':

                    flushInline();

                    resultado.push(

                        ...converterLista(
                            node,
                            json,
                            contexto,
                            opcoes,
                            estado
                        )
                    );

                    break;


                case 'tabela':

                    flushInline();

                    resultado.push(

                        converterTabela(
                            node,
                            json,
                            contexto,
                            opcoes
                        )
                    );

                    break;


                case 'item':

                    inlineNodes.push(
                        node
                    );

                    break;


                default:

                    flushInline();

                    if (
                        node.filhos
                    ) {

                        resultado.push(

                            ...converterBloco(
                                node.filhos,
                                json,
                                contexto,
                                opcoes,
                                nivelSecao || 0,
                                numbering,
                                estado,
                                recuoSecao
                            )
                        );
                    }

                    break;
            }
        }
    );

    flushInline();

    return resultado;
}


/* ================================================================
   NUMERAÇÃO HIERÁRQUICA
   ================================================================ */

function criarOpcoesNumeracao(opcoes) {

    return {

        reference:
            'edmsecoes',

        levels:
            Array.from(
                {
                    length:
                        9
                },
                (_, level) => {

                    /*
                     * nível 0 → 0 cm
                     * nível 1 → 0 cm
                     * nível 2 → 0,5 cm
                     * nível 3 → 1 cm
                     * etc.
                     */
                    const recuo =
                        level <= 1
                            ? 0
                            : (
                                level - 1
                            ) * 0.5;

                    return {

                        level,

                        format:
                            global.docx.LevelFormat.DECIMAL,

                        text:
                            Array.from(
                                {
                                    length:
                                        level + 1
                                },
                                (_, indice) =>
                                    `%${indice + 1}.`
                            ).join(''),

                        alignment:
                            global.docx.AlignmentType.LEFT,

                        start:
                            1,

                        /*
                         * NÃO colocar bold aqui.
                         *
                         * Se colocássemos run.bold na definição
                         * do nível, todos os números dos
                         * parágrafos daquele nível ficariam
                         * em negrito.
                         */
                        style: {
                            run: {
                                    font: opcoes.fonte,
                                    size: ptParaHalfPoint(opcoes.tamanhoFonte),
                                    color: paraHexCor(opcoes.corTexto, '000000')
                                },

                            paragraph: {

                                indent: {

                                    left:
                                        cmParaTwip(
                                            recuo
                                        ),

                                    hanging:
                                        0
                                }
                            }
                        }
                    };
                }
            )
    };
}


/* ================================================================
   NUMERAÇÃO DAS LISTAS
   ================================================================ */

function criarOpcoesLista(
    referencia
) {

    return {

        reference:
            referencia,

        levels: [

            {

                level:
                    0,

                format:
                    global.docx.LevelFormat.DECIMAL,

                text:
                    '%1.',

                alignment:
                    global.docx.AlignmentType.LEFT,

                start:
                    1,

                style: {

                    paragraph: {

                        indent: {

                            left:
                                cmParaTwip(
                                    1.9
                                ),

                            hanging:
                                0
                        }
                    }
                }
            }
        ]
    };
}


/* ================================================================
   CONTAR LISTAS
   ================================================================ */

function contarListas(
    nodes
) {

    let total =
        0;

    (nodes || [])
        .forEach(
            node => {

                if (!node) {
                    return;
                }

                if (
                    node.tipo === 'lista' &&
                    String(
                        node.atributos?.numerada ||
                        ''
                    ).toLowerCase() ===
                    'true'
                ) {
                    total++;
                }

                if (
                    node.filhos
                ) {

                    total +=
                        contarListas(
                            node.filhos
                        );
                }
            }
        );

    return total;
}


/* ================================================================
   GERAR WORD
   ================================================================ */

async function gerarWord(
    json,
    nomeArquivo = 'documento.docx',
    opcoes = {}
) {

    garantirDocx();

    if (
        !json ||
        typeof json !== 'object'
    ) {

        throw new Error(
            'O JSON do documento é inválido.'
        );
    }

    if (
        !json.conteudo ||
        !Array.isArray(
            json.conteudo.filhos
        )
    ) {

        throw new Error(
            'O JSON não possui uma estrutura de conteúdo válida.'
        );
    }

    const cfg =
        mesclarOpcoes(
            opcoes
        );

    const estado = {

        contadorListas:
            0
    };

    const quantidadeListas =
        contarListas(
            json.conteudo.filhos
        );

    const numberingConfig = [];

    if (
        cfg.ativarNumeracaoDocumento
    ) {

        numberingConfig.push(
            criarOpcoesNumeracao(cfg)
        );
    }

    for (
        let i = 1;
        i <= quantidadeListas;
        i++
    ) {

        numberingConfig.push(
            criarOpcoesLista(
                criarReferenciaLista(
                    i
                )
            )
        );
    }

    const children =
        converterBloco(
            json.conteudo.filhos,
            json,
            {},
            cfg,
            0,
            cfg.ativarNumeracaoDocumento
                ? {
                    reference:
                        'edmsecoes'
                }
                : null,
            estado
        );

    const documento =
        new global.docx.Document({

            creator:
                'Gerador de Documentos EDM',

            title:
                String(
                    nomeArquivo
                ).replace(
                    /\.docx$/i,
                    ''
                ),

            description:
                'Documento gerado a partir do modelo JSON do motor EDM.',

            numbering: {

                config:
                    numberingConfig
            },

            sections: [

                {

                    properties: {

                        page: {

                            size: {

                                width:
                                    cmParaTwip(
                                        21
                                    ),

                                height:
                                    cmParaTwip(
                                        29.7
                                    )
                            },

                            margin: {

                                top:
                                    cmParaTwip(
                                        cfg.margemSuperior
                                    ),

                                right:
                                    cmParaTwip(
                                        cfg.margemDireita
                                    ),

                                bottom:
                                    cmParaTwip(
                                        cfg.margemInferior
                                    ),

                                left:
                                    cmParaTwip(
                                        cfg.margemEsquerda
                                    ),

                                header:
                                    cmParaTwip(
                                        cfg.cabecalhoDistancia
                                    ),

                                footer:
                                    cmParaTwip(
                                        cfg.rodapeDistancia
                                    )
                            }
                        }
                    },

                    children
                }
            ]
        });

    const blob =
        await global.docx.Packer.toBlob(
            documento
        );

    const url =
        global.URL.createObjectURL(
            blob
        );

    const link =
        document.createElement(
            'a'
        );

    link.href =
        url;

    link.download =
        String(
            nomeArquivo ||
            'documento.docx'
        ).replace(
            /\.docx$/i,
            ''
        ) +
        '.docx';

    document.body.appendChild(
        link
    );

    link.click();

    document.body.removeChild(
        link
    );

    setTimeout(
        () =>
            global.URL.revokeObjectURL(
                url
            ),
        1000
    );

    return blob;
}


/* ================================================================
   API
   ================================================================ */

global.WordEDM = {

    gerarWord,

    obterOpcoes:
        mesclarOpcoes,

    padroes:
        WORD_PADROES
};

})(window);