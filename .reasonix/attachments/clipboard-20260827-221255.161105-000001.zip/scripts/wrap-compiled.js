// Envolve cada arquivo compilado em IIFE para isolar escopos entre <script> clássicos.
const fs = require('fs');
const path = require('path');

const dir = path.join(__dirname, '..', 'js', 'ui', 'compilado');
if (!fs.existsSync(dir)) {
    console.error('Diretório não encontrado:', dir);
    process.exit(1);
}
for (const f of fs.readdirSync(dir)) {
    if (!f.endsWith('.js')) continue;
    const p = path.join(dir, f);
    const code = fs.readFileSync(p, 'utf8');
    if (code.startsWith('(function(){')) continue; // já embrulhado
    fs.writeFileSync(p, '(function(){\n' + code + '\n})();\n');
}
console.log('wrap-compiled concluído');
