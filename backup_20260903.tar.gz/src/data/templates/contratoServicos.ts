import type { TemplateItem } from "../defaultTemplates";

export const contratoServicos: TemplateItem =
  {
    id: 'contrato-servicos',
    nome: 'Contrato de Prestação de Serviços',
    descricao: 'Contrato padrão de prestação de serviços com qualificação das partes, cláusula de pagamento, confidencialidade e foro.',
    categoria: 'Jurídico',
    xml: `<documento>
    <formulario>
        <grupo titulo="1. Contratante">
            <input id="contratante_nome" label="Razão Social / Nome do Contratante" tipo="texto" placeholder="Empresa Alpha Ltda" descricao="Nome completo do contratante"/>
            <number id="contratante_cnpj" label="CNPJ / CPF do Contratante" tipo="cnpj" placeholder="12.345.678/0001-99" descricao="Documento do contratante"/>
            <input id="contratante_endereco" label="Endereço Completo" tipo="texto" placeholder="Rua das Flores, 100 - Centro" descricao="Endereço da sede"/>
            <input id="contratante_representante" label="Representante Legal" tipo="texto" placeholder="Ana Beatriz Mendes" descricao="Nome do representante legal"/>
        </grupo>

        <grupo titulo="2. Contratada">
            <input id="contratada_nome" label="Razão Social / Nome da Contratada" tipo="texto" placeholder="Beta Soluções Digitais ME" descricao="Nome completo da contratada"/>
            <number id="contratada_cnpj" label="CNPJ da Contratada" tipo="cnpj" placeholder="98.765.432/0001-88" descricao="CNPJ da contratada"/>
            <input id="contratada_endereco" label="Endereço da Contratada" tipo="texto" placeholder="Av. Paulista, 1000 - Bela Vista" descricao="Endereço da sede da contratada"/>
            <input id="contratada_email" label="E-mail de Contato" tipo="email" placeholder="contato@empresa.com.br" descricao="E-mail oficial de notificações"/>
        </grupo>

        <grupo titulo="3. Escopo e Entregas">
            <textarea id="descricao_servico" label="Descrição dos Serviços" placeholder="Detalhamento das entregas e escopo técnico..." descricao="Detalhamento das entregas e escopo técnico"/>
            <tabela id="cronograma_entregas" label="Cronograma de Marcos e Parcelas">
                <coluna id="etapa" label="Etapa / Marco" tipo="input" placeholder="Ex: Fase 1 - Planejamento e Arquitetura"/>
                <coluna id="prazo" label="Prazo Estimado" tipo="input" placeholder="Ex: 30 dias"/>
                <coluna id="valor" label="Valor da Etapa (R$)" tipo="moeda" placeholder="0,00"/>
            </tabela>
            <number id="valor_total" label="Valor Total dos Serviços (R$)" tipo="moeda" min="0" step="0.01" placeholder="0,00"/>
            <select id="forma_pagamento" label="Forma de Pagamento" descricao="Condição de quitação">
                <option>À vista via PIX / Transferência</option>
                <option>Parcelado conforme cronograma de entregas</option>
                <option>Por marcos de entrega (milestones)</option>
            </select>
            <input id="prazo_vigencia" label="Prazo de Vigência Contratual" tipo="texto" placeholder="12 (doze) meses"/>
            <input id="cidade_foro" label="Comarca / Foro de Eleição" tipo="texto" placeholder="São Paulo / SP"/>
        </grupo>
    </formulario>

    <conteudo>
        <titulo>INSTRUMENTO PARTICULAR DE PRESTAÇÃO DE SERVIÇOS</titulo>
        <subtitulo>Contrato nº {{contratante_cnpj}}</subtitulo>

        <secao titulo="DAS PARTES CONTRATANTES">
        De um lado, <b>{{contratante_nome}}</b>, inscrita no CNPJ/MF sob o nº <b>{{contratante_cnpj | cnpj}}</b>, com sede em {{contratante_endereco}}, neste ato representada por seu representante legal, <i>{{contratante_representante}}</i>, doravante denominada simplesmente <b>CONTRATANTE</b>;
        
        E, de outro lado, <b>{{contratada_nome}}</b>, inscrita no CNPJ/MF sob o nº <b>{{contratada_cnpj | cnpj}}</b>, com sede em {{contratada_endereco}}, e-mail para notificações <u>{{contratada_email | email}}</u>, doravante denominada simplesmente <b>CONTRATADA</b>;

        Têm entre si, justo e acordado, o presente Contrato de Prestação de Serviços, mediante as cláusulas e condições seguintes:
        </secao>

        <secao titulo="DO OBJETO DO CONTRATO">
        O presente contrato tem por objeto a prestação dos serviços especializados pela CONTRATADA à CONTRATANTE, compreendendo:
        <i>{{descricao_servico}}</i>.
        </secao>

        <secao titulo="DO CRONOGRAMA DE ENTREGAS E MARCOS">
        A execução dos serviços e os respectivos repasses financeiros seguirão rigorosamente o cronograma abaixo:
        {{cronograma_entregas}}

        <p><b>Destaques e Acessos Diretos às Células da Tabela:</b></p>
        <p>• Primeira Entrega: <b>{{cronograma_entregas.etapa[0]}}</b> (Prazo: {{cronograma_entregas.prazo[0]}}) no valor de <b>R$ {{cronograma_entregas.valor[0] | moeda}}</b>.</p>
        <p>• Relação de todos os prazos cadastrados: {{cronograma_entregas.prazo}}.</p>
        </secao>

        <secao titulo="DO PREÇO E DAS CONDIÇÕES DE PAGAMENTO">
        Pelos serviços prestados, a CONTRATANTE pagará à CONTRATADA o valor total de <b>R$ {{valor_total | moeda}}</b> (<i>{{valor_total | moedaPorExtenso}}</i>).
        A condição de pagamento acordada entre as partes será: <b>{{forma_pagamento}}</b>.
        </secao>

        <secao titulo="DO PRAZO E VIGÊNCIA">
        O presente contrato vigorará pelo prazo de <b>{{prazo_vigencia}}</b>, a contar da data de sua assinatura, podendo ser prorrogado mediante termo aditivo formal.
        </secao>

        <secao titulo="DO FORO">
        Para dirimir quaisquer controvérsias oriundas deste Contrato, as partes elegem o Foro da Comarca de <b>{{cidade_foro}}</b>, com expressa renúncia a qualquer outro, por mais privilegiado que seja.
        </secao>

        <secao titulo="ASSINATURAS" numerar="false">
        Local e Data: {{cidade_foro}}, na data de assinatura digital.
        
        <b>{{contratante_nome}}</b> (CONTRATANTE)
        Representante: {{contratante_representante}}

        <b>{{contratada_nome}}</b> (CONTRATADA)
        </secao>
    </conteudo>
</documento>`,
    json: `{
  "contratante_nome": "Empresa Alpha Soluções Tecnológicas Ltda",
  "contratante_cnpj": "12345678000199",
  "contratante_endereco": "Av. Paulista, 1000 - Bela Vista, São Paulo/SP",
  "contratante_representante": "Ana Beatriz Mendes",
  "contratada_nome": "Beta Soluções Digitais ME",
  "contratada_cnpj": "98765432000188",
  "contratada_endereco": "Rua das Inovações, 500 - Centro, Curitiba/PR",
  "contratada_email": "contato@betasolucoes.com.br",
  "descricao_servico": "Desenvolvimento e sustentação de sistema web sob demanda, incluindo arquitetura em nuvem e suporte técnico especializado.",
  "cronograma_entregas": [
    { "etapa": "Fase 1 - Arquitetura e Protótipo", "prazo": "30 dias", "valor": "15.000,00" },
    { "etapa": "Fase 2 - Implementação do Core", "prazo": "60 dias", "valor": "25.000,00" },
    { "etapa": "Fase 3 - Homologação e Deploy", "prazo": "90 dias", "valor": "10.000,00" }
  ],
  "valor_total": "50000.00",
  "forma_pagamento": "Parcelado conforme cronograma de entregas",
  "prazo_vigencia": "12 (doze) meses",
  "cidade_foro": "São Paulo / SP"
}`
  };
